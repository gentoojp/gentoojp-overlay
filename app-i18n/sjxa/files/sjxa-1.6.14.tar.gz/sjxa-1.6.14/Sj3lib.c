/* $SonyId: Sj3lib.c,v 1.4 1998/09/15 06:33:58 makoto Exp $ */
/******************************************************************

Copyright (c) 1995,1996,1997,1998  Sony Corporation

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL SONY CORPORATION BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of Sony Corporation shall
not be used in advertising or otherwise to promote the sale, use or ot
her dealings in this Software without prior written authorization from
Sony Corporation.

******************************************************************/
#include	<stdio.h>
#include	<netdb.h>
#include	<pwd.h>
#include	<sys/un.h>
#include	<sys/types.h>
#include	<sys/param.h>
#include	<sys/file.h>
#include	<netinet/in.h>
#include	<locale.h>
#include	<setjmp.h>
#include	<ctype.h>
#include	<unistd.h>
#include	<signal.h>
#ifdef TLI
#include	<fcntl.h>
#include	<tiuser.h>
#include	<stropts.h>
#include	<netdir.h>
#include	<netconfig.h>
#else
#include	<sys/socket.h>
#endif

#include	"sj3libP.h"
#include	"sj3lib.h"
#include	"SjString.h"

#ifdef SVR4
#define signal sigset
#endif

static int		 sj3_error_number;

static char		*af_unix_str = "unix";
static u_char		 putbuf[BUFSIZ];
static u_char		 getbuf[BUFSIZ];
static int		 putpos = 0;
static int		 getlen = 0;
static int		 getpos = 0;
static SJ3_CLIENT_ENV	*cliptr;
static int		 server_fd = -1;

#define	INTLEN		sizeof(int)
#define	CMDLEN		sizeof(int)

static int		 ReadErrorFlag = FALSE;

extern char		*program_name;
#ifdef __sony_news
extern int		_sys_code;
#else
#define SYS_SJIS	0
#define SYS_EUC		1
#define SYS_NOTDEF	-1
static int	_sys_code = SYS_NOTDEF;
#endif /* __sony_news */

#define	SJ3_USER_DIR	"user"
static char		*path_delimiter = "/";
static SJ3_CLIENT_ENV	 client = { -1, 0 };
static long		 mdicid = 0;
static long		 udicid = 0;
static int		 defuse = 0;
static long		*dicid_list = NULL;
static int		 dicid_num = 0;

static u_char		 buf1[YomiBufSize];
static u_char		 kbuf[KanjiBufSize];


#define	client_init(p)	{			\
    cliptr = (p);				\
    if( (server_fd = cliptr->fd) == -1 ) {	\
	sj3_error_number = SJ3_NotOpened;	\
	return( SJ3ERROR );			\
    }						\
}


static int
#if NeedFunctionPrototypes
put_flush( void )
#else /* NeedFunctionPrototypes */
put_flush()
#endif /* NeedFunctionPrototypes */
{
    register int	i, j;
    register u_char	*p;

    for( i = putpos, p = putbuf; i > 0; i -= j, p += j ) {
#ifdef TLI
	if( (j = write( server_fd, p, i )) <= 0 ) {
	    t_sndrel( server_fd );
	    close( server_fd );
#else
	if( (j = write( server_fd, p, i )) <= 0 ) {
	    shutdown( server_fd, 2 );
	    close( server_fd );
#endif
	    cliptr->fd = server_fd = -1;
	    sj3_error_number = SJ3_ServerDown;
	    return( SJ3ERROR );
	}
    }
    putpos = 0;
    return( SJ3NOERROR );
}


static void
#if NeedFunctionPrototypes
put_byte( register int	c )
#else /* NeedFunctionPrototypes */
put_byte( c )
    register int	c;
#endif /* NeedFunctionPrototypes */
{
    putbuf[putpos++] = c;
}


static void
#if NeedFunctionPrototypes
put_int( register int c )
#else /* NeedFunctionPrototypes */
put_int( c )
    register int	c;
#endif /* NeedFunctionPrototypes */
{
    put_byte(c >> (8 * 3));
    put_byte(c >> (8 * 2));
    put_byte(c >> (8 * 1));
    put_byte(c);
}


static void
#if NeedFunctionPrototypes
put_cmd( register int cmd )
#else /* NeedFunctionPrototypes */
put_cmd( cmd )
    register int	cmd;
#endif /* NeedFunctionPrototypes */
{
    ReadErrorFlag = FALSE;
    putpos = getlen = 0;
    put_int(cmd);
}


static u_char *
#if NeedFunctionPrototypes
put_ndata( register u_char *p, register int n )
#else /* NeedFunctionPrototypes */
put_ndata( p, n )
    register u_char	*p;
    register int	 n;
#endif /* NeedFunctionPrototypes */
{
    while( n-- > 0 )
	put_byte( p ? *p++ : 0 );
    return( p );
}


static int
#if NeedFunctionPrototypes
put_over( int buflen, int n,
	  u_char *(*func1)(), u_char *str1, int len1,
	  u_char *(*func2)(), u_char *str2, int len2,
	  u_char *(*func3)(), u_char *str3, int len3,
	  u_char *(*func4)(), u_char *str4, int len4 )
#else /* NeedFunctionPrototypes */
put_over( buflen, n, func1, str1, len1, func2, str2, len2,
	  func3, str3, len3, func4, str4, len4 )
    int		 buflen, n;
    u_char	*(*func1)(), *(*func2)(), *(*func3)(), *(*func4)();
    u_char	*str1, *str2, *str3, *str4;
    int		 len1, len2, len3, len4;
#endif /* NeedFunctionPrototypes */
{
#define ARGNUM 4
    u_char	*(*func[ARGNUM])();
    u_char	*data[ARGNUM];
    int		 len[ARGNUM];
    int		 i;

    func[0] = func1; data[0] = str1; len[0] = len1;
    func[1] = func2; data[1] = str2; len[1] = len2;
    func[2] = func3; data[2] = str3; len[2] = len3;
    func[3] = func4; data[3] = str4; len[3] = len4;

    for( i = 0; i < n; i++ ) {
	if( len[i] < buflen ) {
	    (*func[i])( data[i], len[i] );
	    buflen -= len[i];
	}
	else {
	    while( len[i] > 0 ) {
		data[i] = (*func[i])( data[i],
				      (len[i] < buflen) ? len[i] : buflen );
		if( put_flush() == SJ3ERROR )
		    return( SJ3ERROR );
		len[i] -= buflen;
		buflen = BUFSIZ;
	    }
	}
    }
    if( buflen != BUFSIZ  &&  put_flush() == SJ3ERROR )
	return( SJ3ERROR );

    return( 0 );
}


static int
#if NeedFunctionPrototypes
get_buffer( void )
#else /* NeedFunctionPrototypes */
get_buffer()
#endif /* NeedFunctionPrototypes */
{
    if( ReadErrorFlag )
	return( SJ3ERROR );
    getpos = getlen = 0;

    getlen = read( server_fd, getbuf, sizeof(getbuf) );
    if( getlen <= 0 ) {
#ifdef TLI
	t_close( server_fd );
#else
	shutdown( server_fd, 2 );
	close( server_fd );
#endif
	cliptr -> fd = server_fd = -1;
	sj3_error_number = SJ3_ServerDown;
	return( SJ3ERROR );
    }
    return( getlen );
}


static u_char
#if NeedFunctionPrototypes
get_byte( void )
#else /* NeedFunctionPrototypes */
get_byte()
#endif /* NeedFunctionPrototypes */
{
    if( getpos >= getlen  &&  get_buffer() == SJ3ERROR ) {
	ReadErrorFlag = TRUE;
	return( 0 );
    }
    return( getbuf[getpos++] & 0xff );
}


static int
#if NeedFunctionPrototypes
get_int( void )
#else /* NeedFunctionPrototypes */
get_int()
#endif /* NeedFunctionPrototypes */
{
    register int	i0;
    register int	i1;
    register int	i2;

    i0 = get_byte();
    i1 = get_byte();
    i2 = get_byte();
    return( (i0 << (8*3)) | (i1 << (8*2)) | (i2 << (8*1)) | get_byte() );
}


static u_char *
#if NeedFunctionPrototypes
get_string( register u_char *p )
#else /* NeedFunctionPrototypes */
get_string( p )
    register u_char	*p;
#endif /* NeedFunctionPrototypes */
{
    register int	c;

    do {
	*p++ = c = get_byte();
    } while( c );

    return( p );
}


static u_char *
#if NeedFunctionPrototypes
get_ndata( register u_char *p, register int n )
#else /* NeedFunctionPrototypes */
get_ndata( p, n )
    register u_char	*p;
    register int	 n;
#endif /* NeedFunctionPrototypes */
{
    while( n-- > 0 )
	*p++ = get_byte();
    return( p );
}


static void
#if NeedFunctionPrototypes
skip_ndata( register int n )
#else /* NeedFunctionPrototypes */
skip_ndata( n )
    register int	n;
#endif /* NeedFunctionPrototypes */
{
    while(n-- > 0 )
	get_byte();
}


#ifndef TLI
static int
#if NeedFunctionPrototypes
open_unix( void )
#else /* NeedFunctionPrototypes */
open_unix()
#endif /* NeedFunctionPrototypes */
{
    int			fd;
    struct sockaddr_un	sunix;

    sunix.sun_family = AF_UNIX;
    strcpy( sunix.sun_path, SocketName );

    if( (fd = socket( AF_UNIX, SOCK_STREAM, 0 )) == SJ3ERROR ) {
	sj3_error_number = SJ3_OpenSocket;
	return( SJ3ERROR );
    }

    if( connect( fd, (struct sockaddr *)&sunix, sizeof(struct sockaddr_un) )
	== SJ3ERROR ) {
	sj3_error_number = SJ3_ConnectSocket;
	return( SJ3ERROR );
    }

    return( fd );
}
#endif


static int
#if NeedFunctionPrototypes
open_inet( char *host )
#else /* NeedFunctionPrototypes */
open_inet( host )
    char	*host;
#endif /* NeedFunctionPrototypes */
{
#ifdef TLI
    int			 val;
    struct t_call	*callptr;
    struct netconfig	*nconf;
    struct nd_hostserv	 hserv;
    struct nd_addrlist	*addrs;
    void		*handlep;
    char		 host_name[BUFSIZ], proto_name[BUFSIZ];
    char		*port_name, *tmp_addr;
#else
    struct hostent	*hp;
    struct servent	*sp;
    int			 port;
    struct sockaddr_in	 sin;
#endif
    int			 fd, ret;

#ifdef TLI
    if( (tmp_addr = strchr( host, '/' )) != NULL ) {
	strncpy( proto_name, host, (unsigned int)(tmp_addr - host) );
	proto_name[(unsigned int)(tmp_addr - host)] = '\0';
	tmp_addr++;
    }
    else {
	strncpy( proto_name, ProtoName, strlen(ProtoName) );
	proto_name[strlen(ProtoName)] = '\0';
	tmp_addr = host;
    }
    if( (port_name = strchr(tmp_addr, ':')) != NULL ) {
	strncpy( host_name, tmp_addr, (unsigned int)(port_name - tmp_addr) );
	host_name[(unsigned int)(port_name - tmp_addr)] = '\0';
	port_name++;
    }
    else {
	strcpy( host_name, tmp_addr );
	port_name = PortName;
    }
    hserv.h_host = host_name;
    hserv.h_serv = port_name;

    if( (handlep = setnetpath()) == NULL ) {
	sj3_error_number = SJ3_GetHostByName;
	return( SJ3ERROR );
    }
    while( (nconf = getnetpath( handlep )) != NULL ) {
	if( (nconf->nc_semantics == NC_TPI_COTS_ORD  ||
	     nconf->nc_semantics == NC_TPI_COTS)  &&
	    strncmp( nconf->nc_proto, proto_name, strlen(proto_name) ) == 0 )
	    break;
    }
    if( nconf == NULL ) {
	sj3_error_number = SJ3_GetHostByName;
	return( SJ3ERROR );
    }
    if( netdir_getbyname( nconf, &hserv, &addrs ) != 0 ) {
	hserv.h_serv = PortNumber;
	if( netdir_getbyname( nconf, &hserv, &addrs ) != 0 ) {
	    sj3_error_number = SJ3_GetHostByName;
	    return( SJ3ERROR );
	}
    }
    if( (fd = t_open( nconf->nc_device, O_RDWR, (struct t_info *)0) ) < 0 ) {
	sj3_error_number = SJ3_OpenSocket;
	return( SJ3ERROR );
    }
    if( t_bind( fd, (struct t_bind *)0, (struct t_bind *) 0) < 0 ) {
	sj3_error_number = SJ3_OpenSocket;
	return( SJ3ERROR );
    }
#else
    if( !(hp = gethostbyname( host )) ) {
	sj3_error_number = SJ3_GetHostByName;
	return( SJ3ERROR );
    }

    if( sp = getservbyname( PortName, "tcp" ) )
	port = ntohs(sp -> s_port);
    else
	port = PortNumber;

    memset( (char *)&sin, '\0', sizeof(sin) );
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    memcpy( &sin.sin_addr, hp -> h_addr, hp -> h_length );

    if( (fd = socket( AF_INET, SOCK_STREAM, 0 ) ) == SJ3ERROR ) {
	sj3_error_number = SJ3_OpenSocket;
	return( SJ3ERROR );
    }
#endif

#ifdef TLI
    if( (callptr = (struct t_call *)t_alloc( fd, T_CALL, T_ALL )) == NULL ) {
	sj3_error_number = SJ3_NotEnoughMemory;
	return( SJ3ERROR );
    }
    callptr->addr = *(addrs->n_addrs);
    callptr->opt.len = 0;
    callptr->opt.maxlen = 0;
    callptr->opt.buf = (char *)NULL;
    callptr->udata.len = 0;
    callptr->udata.maxlen = 0;
    callptr->udata.buf = (char *)NULL;

    ret = t_connect( fd, callptr, (struct t_call *)0 );
#else
    ret = connect( fd, (struct sockaddr *)&sin, sizeof(sin) );
#endif
    if( ret == SJ3ERROR ) {
	sj3_error_number = SJ3_ConnectSocket;
	return( SJ3ERROR );
    }
#ifdef TLI
    if( ioctl( fd, I_POP, (char *)0 ) < 0 ) {
	sj3_error_number = SJ3_NotOpened;
	return( SJ3ERROR );
    }
    if( ioctl( fd, I_PUSH, "tirdwr" ) < 0 ) {
	sj3_error_number = SJ3_NotOpened;
	return( SJ3ERROR );
    }
    val = 0;
    ioctl( fd, I_SETCLTIME, &val );
    endnetpath( handlep );
#endif

    return( fd );
}


static int
#if NeedFunctionPrototypes
sj3_erase_connection( SJ3_CLIENT_ENV *client )
#else /* NeedFunctionPrototypes */
sj3_erase_connection( client )
    SJ3_CLIENT_ENV	*client;
#endif /* NeedFunctionPrototypes */
{
    client_init( client );

    put_cmd( SJ3_DISCONNECT );
    if( put_flush() == SJ3ERROR )
	return( SJ3ERROR );

    sj3_error_number = get_int();
#ifdef TLI
    t_close( server_fd );
#else
    close( server_fd );
#endif
    cliptr->fd = -1;
    if( ReadErrorFlag )
	return( SJ3ERROR );
    return( sj3_error_number ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_make_connection( SJ3_CLIENT_ENV *client, char *serv, char *user,
		     char *prog )
#else /* NeedFunctionPrototypes */
sj3_make_connection( client, serv, user, prog )
    SJ3_CLIENT_ENV	*client;
    char		*serv;
    char		*user;
    char		*prog;
#endif /* NeedFunctionPrototypes */
{
    char	 host[MAXHOSTNAMELEN];
    int		 tmp;
    int		 hostlen, userlen, proglen, datalen, buflen;
    int		 curlen;
    char	*curdata;

    client->fd = -1;

    if( !serv  ||  *serv == '\0'  ||  !strcmp( serv, af_unix_str ) ) {
#ifdef TLI
	serv = LocalHost;
	strcpy( host, af_unix_str );
    }
    else {
	gethostname( host, sizeof(host) );
    }
    if( (server_fd = open_inet( serv )) == SJ3ERROR )
	return( SJ3ERROR );
#else
	if( (server_fd = open_unix()) == SJ3ERROR )
	    return( SJ3ERROR );
	strcpy( host, af_unix_str );
    }
    else {
	if( (server_fd = open_inet( serv )) == SJ3ERROR )
	    return( SJ3ERROR );
	gethostname( host, sizeof( host ) );
    }
#endif
    client -> fd = server_fd;
    client_init( client );

    hostlen = strlen( host ) + 1;
    userlen = strlen( user ) + 1;
    proglen = strlen( prog ) + 1;
    datalen = hostlen + userlen + proglen;

    put_cmd( SJ3_CONNECT );
    put_int( SJ3SERV_VERSION_NO );
    if( datalen <= (buflen = BUFSIZ - CMDLEN - INTLEN) ) {
	put_ndata( (u_char *)host, hostlen );
	put_ndata( (u_char *)user, userlen );
	put_ndata( (u_char *)prog, proglen );
	if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 3, put_ndata, (u_char *)host, hostlen, put_ndata,
		      (u_char *)user, userlen, put_ndata, (u_char *)prog,
		      proglen, NULL, NULL, 0 ) == SJ3ERROR )
	    return( SJ3ERROR );
    }

    if( (tmp = get_int()) == SJ3_DifferentVersion ) {
	if( ReadErrorFlag )
	    return( SJ3ERROR );
	put_cmd( SJ3_CONNECT );
	put_int( 1 );
	if( datalen <= (buflen = BUFSIZ - CMDLEN - INTLEN) ) {
	    put_ndata( (u_char *)host, hostlen );
	    put_ndata( (u_char *)user, userlen );
	    put_ndata( (u_char *)prog, proglen );
	    if( put_flush() == SJ3ERROR )
		return( SJ3ERROR );
	}
	else {
	    if( put_over( buflen, 3, put_ndata, (u_char *)host, hostlen,
			  put_ndata, (u_char *)user, userlen, put_ndata,
			  (u_char *)prog, proglen, NULL, NULL, 0 ) == SJ3ERROR )
		return( SJ3ERROR );
	}
	if( tmp = get_int() ) {
	    sj3_erase_connection( client );
	    sj3_error_number = tmp;
	    return( SJ3ERROR );
	}
    }
    else if( tmp  &&  -2 < tmp ) {
	sj3_erase_connection( client );
	sj3_error_number = tmp;
	return( SJ3ERROR );
    }
    cliptr->svr_version = tmp ? -tmp : 1;
    cliptr->cli_version = SJ3SERV_VERSION_NO;
    sj3_error_number = 0;

    if( ReadErrorFlag )
	return( SJ3ERROR );
    put_cmd( SJ3_STDYSIZE );
    if( put_flush() == SJ3ERROR )
	return( SJ3ERROR );

    if( tmp = get_int() ) {
	sj3_erase_connection( client );
	sj3_error_number = tmp;
	return( SJ3ERROR );
    }

    cliptr->stdy_size = get_int();
    cliptr->fd = server_fd;

    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static long
#if NeedFunctionPrototypes
sj3_open_dictionary( SJ3_CLIENT_ENV *client, char *dictname, char *password )
#else /* NeedFunctionPrototypes */
sj3_open_dictionary( client, dictname, password )
    SJ3_CLIENT_ENV	*client;
    char		*dictname;
    char		*password;
#endif /* NeedFunctionPrototypes */
{
    int	res;
    int dictlen, passlen;
    int datalen, buflen;

    client_init( client );

    dictlen = strlen(dictname) + 1;
    passlen = (password ? strlen(password) : 0) + 1;
    datalen = dictlen + passlen;

    put_cmd( SJ3_OPENDICT );
    if( datalen < (buflen = BUFSIZ - CMDLEN) ) {
      put_ndata( (u_char *)dictname, dictlen );
      put_ndata( (u_char *)password, passlen );
      if( put_flush() == SJ3ERROR )
	  return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 2, put_ndata, (u_char *)dictname, dictlen,
		      put_ndata, (u_char *)password, passlen, NULL, NULL, 0,
		      NULL, NULL, 0 ) == SJ3ERROR )
	    return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( 0 );
    res = get_int();
    return( ReadErrorFlag ? SJ3ERROR : res );
}


static int
#if NeedFunctionPrototypes
sj3_close_dictionary( SJ3_CLIENT_ENV *client, long dicid )
#else /* NeedFunctionPrototypes */
sj3_close_dictionary( client, dicid )
    SJ3_CLIENT_ENV	*client;
    long		 dicid;
#endif /* NeedFunctionPrototypes */
{
    client_init( client );

    put_cmd( SJ3_CLOSEDICT );
    put_int( dicid );
    if( put_flush() == SJ3ERROR )
	return( SJ3ERROR );

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_open_study_file( SJ3_CLIENT_ENV *client, char *stdyname, char *password )
#else /* NeedFunctionPrototypes */
sj3_open_study_file( client, stdyname, password )
    SJ3_CLIENT_ENV	*client;
    char		*stdyname;
    char		*password;
#endif /* NeedFunctionPrototypes */
{
    int stdylen, passlen;
    int datalen, buflen;

    client_init( client );

    stdylen = strlen(stdyname) + 1;
    passlen = strlen(password) + 1;
    datalen = stdylen + passlen;

    put_cmd( SJ3_OPENSTDY );
    if( datalen < (buflen = BUFSIZ - CMDLEN) ) {
	put_ndata( (u_char *)stdyname, stdylen );
	put_ndata( (u_char *)password, passlen );
	if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 2, put_ndata, (u_char *)stdyname, stdylen,
		      put_ndata, (u_char *)password, passlen, NULL, NULL, 0,
		      NULL, NULL, 0 ) == SJ3ERROR )
	    return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_close_study_file( SJ3_CLIENT_ENV *client )
#else /* NeedFunctionPrototypes */
sj3_close_study_file( client )
    SJ3_CLIENT_ENV	*client;
#endif /* NeedFunctionPrototypes */
{
    client_init( client );

    put_cmd( SJ3_CLOSESTDY );
    if( put_flush() == SJ3ERROR )
	return( SJ3ERROR );

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_lock_server( SJ3_CLIENT_ENV	*client )
#else /* NeedFunctionPrototypes */
sj3_lock_server( client )
    SJ3_CLIENT_ENV	*client;
#endif /* NeedFunctionPrototypes */
{
    client_init( client );

    put_cmd( SJ3_LOCK );
    if( put_flush() == SJ3ERROR )
	return( SJ3ERROR );

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_unlock_server( SJ3_CLIENT_ENV *client )
#else /* NeedFunctionPrototypes */
sj3_unlock_server( client )
    SJ3_CLIENT_ENV	*client;
#endif /* NeedFunctionPrototypes */
{
    client_init( client );

    put_cmd( SJ3_UNLOCK );
    if( put_flush() == SJ3ERROR )
	return( SJ3ERROR );

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_ikkatu_henkan( SJ3_CLIENT_ENV *client, u_char *src, register u_char *dst,
		   register int dstsiz, int mb_flag )
#else /* NeedFunctionPrototypes */
sj3_ikkatu_henkan( client, src, dst, dstsiz, mb_flag )
    SJ3_CLIENT_ENV	*client;
    u_char		*src;
    register u_char	*dst;
    register int	 dstsiz;
    int			 mb_flag;
#endif /* NeedFunctionPrototypes */
{
    register int	 c;
    u_char		*top;
    int			 result;
    int			 len;
    int			 len1;
    int			 stysiz;
    int     		 srclen;
    int     		 buflen;

    client_init( client );

    srclen = strlen( (char *)src ) + 1;

    if( mb_flag == MBCODE_SJIS )
	put_cmd( SJ3_PH2KNJ );
    else
	put_cmd( SJ3_PH2KNJ_EUC );
    if( srclen < (buflen = BUFSIZ - CMDLEN) ) {
	put_ndata( src, srclen );
	if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 1, put_ndata, src, srclen, NULL, NULL, 0,
		      NULL, NULL, 0, NULL, NULL, 0 ) == SJ3ERROR )
	    return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );

    result = get_int();

    result = 0;
    stysiz = cliptr->stdy_size;
    len1 =  1 + stysiz + 1 + 1;
    while( c = get_byte() ) {
	top = dst;
	if( dstsiz < len1 )
	    goto error1;

	*dst++ = len = c;
	dst = get_ndata( dst, stysiz );
	dstsiz -= stysiz + 1;

	while( c = get_byte() ) {
	    if( dstsiz-- < 3 )
		goto error2;
	    *dst++ = c;
	}
	*dst++ = 0;
	dstsiz--;
	result += len;
    }

    *dst = 0;
    return( ReadErrorFlag ? SJ3ERROR : result );

error1:
    do {
	skip_ndata( stysiz );
error2:
	while( get_byte() );
    } while( get_byte() );

    *top = 0;
    return( ReadErrorFlag ? SJ3ERROR : result );
}


static int
#if NeedFunctionPrototypes
sj3_bunsetu_kouhosuu( SJ3_CLIENT_ENV *client, u_char *yomi, int len,
		      int mb_flag )
#else /* NeedFunctionPrototypes */
sj3_bunsetu_kouhosuu( client, yomi, len, mb_flag )
    SJ3_CLIENT_ENV	*client;
    u_char		*yomi;
    int			 len;
    int			 mb_flag;
#endif /* NeedFunctionPrototypes */
{
    int	result;
    int	buflen;

    client_init( client );

    if( mb_flag == MBCODE_SJIS )
	put_cmd( SJ3_CL2KNJ_CNT );
    else
	put_cmd( SJ3_CL2KNJ_CNT_EUC );
    put_int( len );
    if( (len + 1) <= (buflen = BUFSIZ - CMDLEN - INTLEN) ) {
	put_ndata( yomi, len );
	put_byte( 0 );
	if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
          if( put_over( buflen, 2, put_ndata, yomi, len, put_ndata, NULL, 1,
			NULL, NULL, 0, NULL, NULL, 0 ) == SJ3ERROR )
            return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );

    result = get_int();
    return( ReadErrorFlag ? SJ3ERROR : result );
}


static int
#if NeedFunctionPrototypes
sj3_bunsetu_zenkouho( SJ3_CLIENT_ENV *client, u_char *yomi, int len,
		      SJ3_DOUON *douon, int mb_flag )
#else /* NeedFunctionPrototypes */
sj3_bunsetu_zenkouho( client, yomi, len, douon, mb_flag )
    SJ3_CLIENT_ENV	*client;
    u_char		*yomi;
    int			 len;
    SJ3_DOUON		*douon;
    int     mb_flag;
#endif /* NeedFunctionPrototypes */
{
    int	cnt = 0;
    int	buflen;

    client_init( client );

    if( mb_flag == MBCODE_SJIS )
	put_cmd( SJ3_CL2KNJ_ALL );
    else
	put_cmd( SJ3_CL2KNJ_ALL_EUC );
    put_int( len );
    if( (len + 1) <= (buflen = BUFSIZ - CMDLEN - INTLEN) ) {
	put_ndata( yomi, len );
	put_byte( 0 );
	if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 2, put_ndata, yomi, len, put_ndata, NULL, 1,
		      NULL, NULL, 0, NULL, NULL, 0 ) == SJ3ERROR )
	    return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );

    while( get_int() ) {
	get_ndata( (u_char *)&douon->dcid, cliptr->stdy_size );
	get_string( douon -> ddata );
	douon->dlen = strlen( (char *)douon->ddata );
	douon++;
	cnt++;
    }

    return( ReadErrorFlag ? SJ3ERROR : cnt );
}


static int
#if NeedFunctionPrototypes
sj3_tango_gakusyuu( SJ3_CLIENT_ENV *client, SJ3_STUDYREC *stdy )
#else /* NeedFunctionPrototypes */
sj3_tango_gakusyuu( client, stdy )
    SJ3_CLIENT_ENV	*client;
    SJ3_STUDYREC	*stdy;
#endif /* NeedFunctionPrototypes */
{
    int	buflen;

    client_init( client );

    put_cmd( SJ3_STUDY );
    if( cliptr->stdy_size <= (buflen = BUFSIZ - CMDLEN) ) {
	put_ndata( (u_char *)stdy, cliptr->stdy_size );
        if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 1, put_ndata, (u_char *)stdy, cliptr -> stdy_size,
		      NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0 )
		      == SJ3ERROR )
            return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_bunsetu_gakusyuu( SJ3_CLIENT_ENV *client, u_char *yomi1, u_char *yomi2,
		      SJ3_STUDYREC *stdy, int mb_flag )
#else /* NeedFunctionPrototypes */
sj3_bunsetu_gakusyuu( client, yomi1, yomi2, stdy, mb_flag )
    SJ3_CLIENT_ENV	*client;
    u_char		*yomi1;
    u_char		*yomi2;
    SJ3_STUDYREC	*stdy;
    int			 mb_flag;
#endif /* NeedFunctionPrototypes */
{
    int	yomilen1, yomilen2;
    int	datalen, buflen;

    client_init( client );

    yomilen1 = strlen( (char *)yomi1 ) + 1;
    yomilen2 = strlen( (char *)yomi2 ) + 1;
    datalen = yomilen1 + yomilen2 + cliptr->stdy_size;

    if( mb_flag == MBCODE_SJIS )
	put_cmd( SJ3_CLSTUDY );
    else
  	put_cmd( SJ3_CLSTUDY_EUC );
    if( datalen <= (buflen = BUFSIZ - CMDLEN) ) {
	put_ndata( yomi1, yomilen1 );
	put_ndata( yomi2, yomilen2 );
	put_ndata( (u_char *)stdy, cliptr->stdy_size );
        if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 3, put_ndata, yomi1, yomilen1, put_ndata,
		      yomi2, yomilen2, put_ndata, (u_char *)stdy,
		      cliptr->stdy_size, NULL, NULL, 0 ) == SJ3ERROR )
	return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_tango_touroku( SJ3_CLIENT_ENV *client, long dicid, u_char *yomi,
		   u_char *kanji, int code, int mb_flag )
#else /* NeedFunctionPrototypes */
sj3_tango_touroku( client, dicid, yomi, kanji, code, mb_flag )
    SJ3_CLIENT_ENV	*client;
    long		 dicid;
    u_char		*yomi;
    u_char		*kanji;
    int			 code;
    int			 mb_flag;
#endif /* NeedFunctionPrototypes */
{
    int	yomilen, kanjilen;
    int	datalen, buflen;

    client_init( client );

    yomilen = strlen( (char *)yomi ) + 1;
    kanjilen = strlen( (char *)kanji ) + 1;
    datalen = yomilen + kanjilen + INTLEN;

    if( mb_flag == MBCODE_SJIS )
	put_cmd( SJ3_ADDDICT );
    else
	put_cmd( SJ3_ADDDICT_EUC );
    put_int( dicid );
    if( datalen <= (buflen = BUFSIZ - CMDLEN -INTLEN) ) {
	put_ndata( yomi, yomilen );
	put_ndata( kanji, kanjilen );
	put_int( code );
        if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 3, put_ndata, yomi, yomilen, put_ndata, kanji,
		      kanjilen, put_ndata, (u_char *)&code, INTLEN, NULL, NULL,
		      0 ) == SJ3ERROR )
	    return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_tango_sakujo( SJ3_CLIENT_ENV *client, long dicid, u_char *yomi,
		  u_char *kanji, int code, int mb_flag )
#else /* NeedFunctionPrototypes */
sj3_tango_sakujo( client, dicid, yomi, kanji, code, mb_flag )
    SJ3_CLIENT_ENV	*client;
    long		 dicid;
    u_char		*yomi;
    u_char		*kanji;
    int			 code;
    int			 mb_flag;
#endif /* NeedFunctionPrototypes */
{
    int	yomilen, kanjilen;
    int	datalen, buflen;

    client_init( client );

    yomilen = strlen( (char *)yomi ) + 1;
    kanjilen = strlen( (char *)kanji ) + 1;
    datalen = yomilen + kanjilen + INTLEN;

    if( mb_flag == MBCODE_SJIS )
	put_cmd( SJ3_DELDICT );
    else
	put_cmd( SJ3_DELDICT_EUC );
    put_int( dicid );
    if( datalen <= (buflen = BUFSIZ - CMDLEN - INTLEN) ) {
	put_ndata( yomi, yomilen );
	put_ndata( kanji, kanjilen );
	put_int( code );
        if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 3, put_ndata, yomi, yomilen, put_ndata, kanji,
		      kanjilen, put_ndata, (u_char *)&code, INTLEN, NULL, NULL,
		      0 ) == SJ3ERROR )
            return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_tango_syutoku( SJ3_CLIENT_ENV *client, int dicid, u_char *buf, int mb_flag )
#else /* NeedFunctionPrototypes */
sj3_tango_syutoku( client, dicid, buf, mb_flag )
    SJ3_CLIENT_ENV	*client;
    int			 dicid;
    u_char		*buf;
    int			 mb_flag;
#endif /* NeedFunctionPrototypes */
{
    register u_char	*p;

    client_init( client );

    if( mb_flag == MBCODE_SJIS )
	put_cmd( SJ3_GETDICT );
    else
	put_cmd( SJ3_GETDICT_EUC );
    put_int( dicid );
    if( put_flush() == SJ3ERROR )
	return( SJ3ERROR );

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );

    p = get_string( buf );
    p = get_string( p );
    *p = get_int();
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_tango_jikouho( SJ3_CLIENT_ENV *client, int dicid, u_char *buf,
		   int mb_flag )
#else /* NeedFunctionPrototypes */
sj3_tango_jikouho( client, dicid, buf, mb_flag )
    SJ3_CLIENT_ENV	*client;
    int			 dicid;
    u_char		*buf;
    int			 mb_flag;
#endif /* NeedFunctionPrototypes */
{
    register u_char	*p;

    client_init( client );

    if( mb_flag == MBCODE_SJIS )
	put_cmd( SJ3_NEXTDICT );
    else
	put_cmd( SJ3_NEXTDICT_EUC );
    put_int( dicid );
    if( put_flush() == SJ3ERROR )
	return( SJ3ERROR );

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );

    p = get_string( buf );
    p = get_string( p );
    *p = get_int();
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_make_dict_file( SJ3_CLIENT_ENV *client, char *path, int idxlen, int seglen,
		    int segnum )
#else /* NeedFunctionPrototypes */
sj3_make_dict_file( client, path, idxlen, seglen, segnum )
    SJ3_CLIENT_ENV	*client;
    char		*path;
    int			 idxlen;
    int			 seglen;
    int			 segnum;
#endif /* NeedFunctionPrototypes */
{
    int	pathlen;
    int buflen, datalen;

    client_init( client );

    pathlen = strlen( path ) + 1;
    datalen = pathlen + INTLEN + INTLEN + INTLEN;

    put_cmd( SJ3_MAKEDICT );
    if( datalen <= (buflen = BUFSIZ - CMDLEN) ) {
	put_ndata( (u_char *)path, pathlen );
	put_int( idxlen );
	put_int( seglen );
	put_int( segnum );
	if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 4, put_ndata, (u_char *)path, pathlen, put_ndata,
		      (u_char *)&idxlen, INTLEN, put_ndata, (u_char *)&seglen,
		      INTLEN, put_ndata, (u_char *)&segnum, 0 ) == SJ3ERROR )
            return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_make_study_file( SJ3_CLIENT_ENV *client, char *path, int stynum,
		     int clstep, int cllen )
#else /* NeedFunctionPrototypes */
sj3_make_study_file( client, path, stynum, clstep, cllen )
    SJ3_CLIENT_ENV	*client;
    char		*path;
    int			 stynum;
    int			 clstep;
    int			 cllen;
#endif /* NeedFunctionPrototypes */
{
    int pathlen;
    int buflen, datalen;

    client_init( client );

    pathlen = strlen( path ) + 1;
    datalen = pathlen + INTLEN + INTLEN + INTLEN;

    put_cmd( SJ3_MAKESTDY );
    if( datalen <= (buflen = BUFSIZ - CMDLEN) ) {
	put_ndata( (u_char *)path, pathlen );
	put_int( stynum );
	put_int( clstep );
	put_int( cllen );
        if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 4, put_ndata, (u_char *)path, pathlen, put_ndata,
		      (u_char *)&stynum, INTLEN, put_ndata, (u_char *)&clstep,
		      INTLEN, put_ndata, (u_char *)&cllen, 0 ) == SJ3ERROR )
            return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_make_directory( SJ3_CLIENT_ENV *client, char *path )
#else /* NeedFunctionPrototypes */
sj3_make_directory( client, path )
    SJ3_CLIENT_ENV	*client;
    char		*path;
#endif /* NeedFunctionPrototypes */
{
    int pathlen;
    int buflen;

    client_init( client );

    pathlen = strlen( path ) + 1;

    put_cmd( SJ3_MAKEDIR );
    if( pathlen <= (buflen = BUFSIZ - CMDLEN) ) {
	put_ndata( (u_char *)path, pathlen );
        if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 1, put_ndata, (u_char *)path, pathlen, NULL, NULL,
		      0, NULL, NULL, 0, NULL, NULL, 0 ) == SJ3ERROR )
	return( SJ3ERROR );
    }

    if( sj3_error_number = get_int() )
	return( SJ3ERROR );
    return( ReadErrorFlag ? SJ3ERROR : 0 );
}


static int
#if NeedFunctionPrototypes
sj3_access( SJ3_CLIENT_ENV *client, char *path, int mode )
#else /* NeedFunctionPrototypes */
sj3_access( client, path, mode )
    SJ3_CLIENT_ENV	*client;
    char		*path;
    int			 mode;
#endif /* NeedFunctionPrototypes */
{
    int result;
    int pathlen;
    int buflen, datalen;

    client_init( client );

    pathlen = strlen( path ) + 1;
    datalen = pathlen + INTLEN;

    put_cmd( SJ3_ACCESS );
    if( datalen <= (buflen = BUFSIZ - CMDLEN) ) {
	put_ndata( (u_char *)path, pathlen );
	put_int( mode );
        if( put_flush() == SJ3ERROR )
	    return( SJ3ERROR );
    }
    else {
	if( put_over( buflen, 2, put_ndata, (u_char *)path, pathlen, put_ndata,
		      (u_char *)&mode, INTLEN, NULL, NULL, 0, NULL, NULL, 0 )
	    == SJ3ERROR )
	    return( SJ3ERROR );
    }

    sj3_error_number = 0;
    result = get_int();
    return( ReadErrorFlag ? SJ3ERROR : result );
}


#ifndef __sony_news
static int
#if NeedFunctionPrototypes
set_sys_code( void )
#else /* NeedFunctionPrototypes */
set_sys_code()
#endif /* NeedFunctionPrototypes */
{
    char	*loc;

    loc = setlocale( LC_CTYPE, NULL );
    if( strcmp( loc, "ja_JP.SJIS" ) == 0 )
	return( SYS_SJIS );

    return( SYS_EUC );
}
#endif /* __sony_news */


static int
#if NeedFunctionPrototypes
make_dirs( char *path )
#else /* NeedFunctionPrototypes */
make_dirs( path )
    char	*path;
#endif /* NeedFunctionPrototypes */
{
    char		 tmp[PathNameLen];
    register char	*p;
    int			 i;

    for( p = path; *p; p++ ) {
	if( *p != *path_delimiter )
	    continue;

	strncpy( tmp, path, (i = p - path) );
	tmp[i] = '\0';
	if( sj3_access( &client, tmp, F_OK ) != SJ3ERROR )
	    continue;
	if( sj3_error_number == SJ3_ServerDown )
	    return( SJ3ERROR );

	if( sj3_make_directory( &client, tmp ) == SJ3ERROR )
	    return( SJ3ERROR );
    }
    return( SJ3NOERROR );
}


int
#if NeedFunctionPrototypes
sj3_open( char *host, char *user )
#else /* NeedFunctionPrototypes */
sj3_open( host, user )
    char	*host;
    char	*user;
#endif /* NeedFunctionPrototypes */
{
    char	 tmp[PathNameLen];
    char	*p;
    int		 err = SJ3_NORMAL_END;

    if( client.fd != -1 )
	return( SJ3_ALREADY_CONNECTED );

    sprintf( tmp, "%s.%d", program_name, getpid() );
    if( sj3_make_connection( &client, host, user, tmp ) == SJ3ERROR ) {
	if( sj3_error_number == SJ3_ServerDown )
	    goto server_dead;
	client.fd = -1;
	return( SJ3_CONNECT_ERROR );
    }

    if( client.stdy_size > SJ3_WORD_ID_SIZE ) {
	sj3_erase_connection( &client );
	return( SJ3_CONNECT_ERROR );
    }

    mdicid = sj3_open_dictionary( &client, MainDictionary, NULL );
    if( mdicid == 0 ) {
	if( sj3_error_number == SJ3_ServerDown )
	    goto server_dead;
	err |= SJ3_CANNOT_OPEN_MDICT;
    }

    strcpy( tmp, SJ3_USER_DIR );
    if( tmp[strlen(tmp) - 1] != *path_delimiter )
	strcat( tmp, path_delimiter );
    strcat( tmp, user );
    strcat( tmp, path_delimiter );
    if( make_dirs( tmp ) == SJ3ERROR ) {
	if( sj3_error_number == SJ3_ServerDown )
	    goto server_dead;
	return( err | SJ3_CANNOT_MAKE_UDIR );
    }

    for( p = tmp; *p; p++ );
    strcpy( p, UserDictionary );
    if( sj3_access( &client, tmp, F_OK ) == SJ3ERROR ) {
	if( sj3_error_number == SJ3_ServerDown )
	    goto server_dead;
	if( sj3_make_dict_file( &client, tmp, DefIdxLen, DefSegLen, DefSegNum )
	    == SJ3ERROR ) {
	    if( sj3_error_number == SJ3_ServerDown )
		goto server_dead;
	    err |= SJ3_CANNOT_MAKE_UDICT;
	}
    }
    udicid = sj3_open_dictionary( &client, tmp, "" );
    if( udicid == 0 ) {
	if( sj3_error_number == SJ3_ServerDown )
	    goto server_dead;
	err |= SJ3_CANNOT_OPEN_UDICT;
    }

    strcpy( p, StudyFile );
    if( sj3_access( &client, tmp, F_OK ) == SJ3ERROR ) {
	if( sj3_error_number == SJ3_ServerDown )
	    goto server_dead;
	if( sj3_make_study_file( &client, tmp, DefStyNum, DefClStep, DefClLen )
	    == SJ3ERROR ) {
	    if( sj3_error_number == SJ3_ServerDown )
		goto server_dead;
	    err |= SJ3_CANNOT_MAKE_STUDY;
	}
    }
    if( sj3_open_study_file( &client, tmp, "" ) == SJ3ERROR ) {
	if( sj3_error_number == SJ3_ServerDown )
	goto server_dead;
	err |= SJ3_CANNOT_OPEN_STUDY;
    }

    return( err );

server_dead:
    mdicid = udicid = 0;
    return( SJ3_SERVER_DEAD );
}


int
#if NeedFunctionPrototypes
sj3_close( void )
#else /* NeedFunctionPrototypes */
sj3_close()
#endif /* NeedFunctionPrototypes */
{
    int	err = SJ3_NORMAL_END;
    int	i;

    if( client.fd == -1 )
	return( SJ3_NOT_CONNECTED );

    if( mdicid == 0 )
	err |= SJ3_NOT_OPENED_MDICT;
    else if( dicid_list ) {
	for( i = 0; i < dicid_num; i++ ) {
	    if( sj3_close_dictionary( &client, dicid_list[i] ) == SJ3ERROR ) {
		if( sj3_error_number == SJ3_ServerDown )
		    goto server_dead;
		err |= SJ3_CLOSE_MDICT_ERROR;
	    }
	}
	free( dicid_list );
	dicid_list = NULL;
	dicid_num = 0;
    }
    else if( sj3_close_dictionary( &client, mdicid ) == SJ3ERROR ) {
	if( sj3_error_number == SJ3_ServerDown )
	    goto server_dead;
	err |= SJ3_CLOSE_MDICT_ERROR;
    }
    mdicid = 0;

    if( udicid == 0 )
	err |= SJ3_NOT_OPENED_UDICT;
    else if( sj3_close_dictionary( &client, udicid ) == SJ3ERROR ) {
	if( sj3_error_number == SJ3_ServerDown )
	    goto server_dead;
	err |= SJ3_CLOSE_UDICT_ERROR;
    }
    udicid = 0;

    if( sj3_close_study_file( &client ) == SJ3ERROR ) {
	switch( sj3_error_number ) {
	  case SJ3_ServerDown:
	    goto server_dead;

	  case SJ3_StdyFileNotOpened:
	    err |= SJ3_NOT_OPENED_STUDY;
	    break;

	  default:
	    err |= SJ3_CLOSE_STUDY_ERROR;
	    break;
	}
    }

    if( sj3_erase_connection( &client ) ) {
	if( sj3_error_number == SJ3_ServerDown )
	    goto server_dead;
	err |= SJ3_DISCONNECT_ERROR;
    }

    return( err );

server_dead:
    if( dicid_list ) {
	free( dicid_list );
	dicid_list = NULL;
    }
    dicid_num = 0;
    mdicid = udicid = 0;
    return( SJ3_SERVER_DEAD );
}


#if NeedFunctionPrototypes
sj3_getkan( u_char *yomi, SJ3_BUNSETU *bun, u_char *knj, int knjsiz )
#else /* NeedFunctionPrototypes */
sj3_getkan( yomi, bun, knj, knjsiz )
    u_char	*yomi;
    SJ3_BUNSETU	*bun;
    u_char	*knj;
    int		 knjsiz;
#endif /* NeedFunctionPrototypes */
{
    u_char	*src;
    int		 buncnt = 0;
    int		 len;
    int		 stysiz = client.stdy_size;

    if( (len = strlen( (char *)yomi )) > SJ3_IKKATU_YOMI )
	return( 0 );

    while( *yomi ) {
	len = sj3_ikkatu_henkan( &client, yomi, knj, knjsiz, MBCODE_SJIS );
	if( len == SJ3ERROR ) {
	    if( client.fd < 0 ) {
		mdicid = udicid = 0;
		return( -1 );
	    }

	    return( 0 );
	}
	else if( len == 0 )
	    break;

	src = knj;
	while( *src ) {
	    bun->srclen = *src++;
	    memcpy( &bun->dcid, src, stysiz );
	    src += stysiz;
	    bun->destlen = strlen( (char *)src );
	    bun->srcstr = yomi;
	    bun->deststr = knj;
	    while( *src )
		*knj++ = *src++;
	    knjsiz -= bun->destlen;
	    src++;
	    yomi += bun->srclen;
	    bun++;
	    buncnt++;
	}
	*knj = 0;
    }

    if( *yomi ) {
	bun->srclen = strlen( (char *)yomi );
	bun->srcstr = yomi;
	bun->destlen = 0;
	bun->deststr = NULL;
	memset( &bun->dcid, '\0', sizeof(bun->dcid) );
	buncnt++;
    }

    return( buncnt );
}


static int
#if NeedFunctionPrototypes
sj3_getkan_euc( u_char *yomi, SJ3_BUNSETU *bun, u_char *knj, int knjsiz )
#else /* NeedFunctionPrototypes */
sj3_getkan_euc( yomi, bun, knj, knjsiz )
    u_char	*yomi;
    SJ3_BUNSETU	*bun;
    u_char	*knj;
    int		 knjsiz;
#endif /* NeedFunctionPrototypes */
{
    u_char	*src, *yp, *kp, *khp, *ytp;
    int		 buncnt = 0, i;
    int		 len, flag, mflag = 0;
    int		 stysiz = client.stdy_size;
    int		 knjorg = knjsiz;
    SJ3_BUNSETU	*hbun = bun;

    if( (len = strlen( (char *)yomi )) > SJ3_IKKATU_YOMI )
	return( 0 );
    if( client.svr_version == 1 ) {
	defuse = 0;
	yp = ytp = (u_char *)Euc2Sjis( (char *)yomi );
	if( yp[0] == '\0' )
	    return( 0 );
	if( knjsiz > sizeof(kbuf) ) {
	    mflag = 1;
	    kp = khp = (u_char *)malloc( knjsiz );
	}
	else {
	    kp = khp = kbuf;
	}
	flag = MBCODE_SJIS;
    }
    else {
	yp = yomi;
	kp = knj;
	flag = MBCODE_EUC;
    }

    while( *yp ) {
	len = sj3_ikkatu_henkan( &client, yp, kp, knjsiz, flag );
	if( len == SJ3ERROR ) {
	    if( client.fd < 0 ) {
		mdicid = udicid = 0;
		return( -1 );
	    }
	    return( 0 );
	}
	else if( len == 0 )
	    break;

	src = kp;
	while( *src ) {
	    bun->srclen = *src++;
	    memcpy( &bun->dcid, src, stysiz );
	    src += stysiz;
	    bun->destlen = strlen( (char *)src );
	    bun->srcstr = yp;
	    bun->deststr = kp;
	    while( *src )
		*kp++ = *src++;
	    knjsiz -= bun->destlen;
	    src++;
	    yp += bun -> srclen;
	    bun++;
	    buncnt++;
	}
	*kp = 0;
    }

    if( *yp ) {
	bun->srclen = strlen( (char *)yp );
	bun->srcstr = yp;
	bun->destlen = 0;
	bun->deststr = NULL;
	memset( &bun->dcid, '\0', sizeof(bun->dcid) );
	buncnt++;
    }

    if( client.svr_version == 1 ) {
	kp = khp;
	bun = hbun;

	strcpy( (char *)knj, Sjis2Euc( (char *)kp ) );
	if( knj[0] == '\0' )
	    return( 0 );
	for( i = 0; i < buncnt; i++ ) {
	    bun[i].srclen = Sjis2EucLen( (char *)bun[i].srcstr, bun[i].srclen );
	    bun[i].srcstr = yomi + Sjis2EucLen( (char *)ytp,
						bun[i].srcstr - ytp );
	    bun[i].destlen = Sjis2EucLen( (char *)bun[i].deststr,
					  bun[i].destlen );
	    bun[i].deststr = knj + Sjis2EucLen( (char *)kp,
						bun[i].deststr - kp );
	}
	if( mflag ) {
	    free( khp );
	    mflag = 0;
	}
    }

    return( buncnt );
}


int
#if NeedFunctionPrototypes
sj3_getkan_mb( u_char *yomi, SJ3_BUNSETU *bun, u_char *knj, int knjsiz )
#else /* NeedFunctionPrototypes */
sj3_getkan_mb( yomi, bun, knj, knjsiz )
    u_char	*yomi;
    SJ3_BUNSETU	*bun;
    u_char	*knj;
    int		 knjsiz;
#endif /* NeedFunctionPrototypes */
{
#ifndef __sony_news
    if( _sys_code == SYS_NOTDEF )
	_sys_code = set_sys_code();
#endif
    if( _sys_code == SYS_EUC )
	return( sj3_getkan_euc( yomi, bun, knj, knjsiz ) );
    else
	return( sj3_getkan( yomi, bun, knj, knjsiz ) );
}


int
#if NeedFunctionPrototypes
sj3_douoncnt( u_char *yomi )
#else /* NeedFunctionPrototypes */
sj3_douoncnt( yomi )
    u_char	*yomi;
#endif /* NeedFunctionPrototypes */
{
    int	i;

    if( (i = strlen( (char *)yomi )) > SJ3_BUNSETU_YOMI )
	return( 0 );

    i = sj3_bunsetu_kouhosuu( &client, yomi, i, MBCODE_SJIS );
    if( i == SJ3ERROR ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return 0;
    }

    return( i );
}


static int
#if NeedFunctionPrototypes
sj3_douoncnt_euc( u_char *yomi )
#else /* NeedFunctionPrototypes */
sj3_douoncnt_euc( yomi )
    u_char	*yomi;
#endif /* NeedFunctionPrototypes */
{
    int		 i, flag;
    u_char	*yp;

    if( (i = strlen( (char *)yomi )) > SJ3_BUNSETU_YOMI )
	return( 0 );

    if( client.svr_version == 1 ) {
	defuse = 0;
	yp = (u_char *)Euc2Sjis( (char *)yomi );
	if( yp[0] == '\0' )
	    return( 0 );
	flag = MBCODE_SJIS;
    }
    else {
	yp = yomi;
	flag = MBCODE_EUC;
    }
    i = sj3_bunsetu_kouhosuu( &client, yp, i, flag );
    if( i == SJ3ERROR ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return( 0 );
    }

    return( i );
}


int
#if NeedFunctionPrototypes
sj3_douoncnt_mb( u_char *yomi )
#else /* NeedFunctionPrototypes */
sj3_douoncnt_mb( yomi )
    u_char	*yomi;
#endif /* NeedFunctionPrototypes */
{
#ifndef __sony_news
    if( _sys_code == SYS_NOTDEF )
	_sys_code = set_sys_code();
#endif
    if( _sys_code == SYS_EUC )
	return( sj3_douoncnt_euc( yomi ) );
    else
	return( sj3_douoncnt( yomi ) );
}


int
#if NeedFunctionPrototypes
sj3_getdouon( u_char *yomi, SJ3_DOUON *dou )
#else /* NeedFunctionPrototypes */
sj3_getdouon( yomi, dou )
    u_char	*yomi;
    SJ3_DOUON	*dou;
#endif /* NeedFunctionPrototypes */
{
    int	i;

    if( (i = strlen( (char *)yomi )) > SJ3_BUNSETU_YOMI )
	return( 0 );

    i = sj3_bunsetu_zenkouho( &client, yomi, i, dou, MBCODE_SJIS );
    if( i == SJ3ERROR ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return( 0 );
    }

    return( i );
}


static int
#if NeedFunctionPrototypes
sj3_getdouon_euc( u_char *yomi, SJ3_DOUON *dou )
#else /* NeedFunctionPrototypes */
sj3_getdouon_euc( yomi, dou )
    u_char	*yomi;
    SJ3_DOUON	*dou;
#endif /* NeedFunctionPrototypes */
{
    int		 i, j;
    char	*s;

    if( (i = strlen( (char *)yomi )) > SJ3_BUNSETU_YOMI )
	return( 0 );

    if( client.svr_version == 1 ) {
	defuse = 0;
	s = Euc2Sjis( (char *)yomi );
	if( s[0] == '\0' )
	    return( 0 );
	i = sj3_bunsetu_zenkouho( &client, (u_char *)s, i, dou, MBCODE_SJIS );
	if( i == SJ3ERROR ) {
	    if( client.fd < 0 ) {
		mdicid = udicid = 0;
		return( -1 );
	    }
	    return( 0 );
	}
	for( j = 0; j < i; j++ ) {
	    s = Sjis2Euc( (char *)dou[j].ddata );
	    if( s[0] == '\0' )
		return( 0 );
	    strcpy( (char *)dou[j].ddata, s );
	    dou[j].dlen = strlen( s );
	}
    }
    else {
	i = sj3_bunsetu_zenkouho( &client, yomi, i, dou, MBCODE_EUC );
	if( i == SJ3ERROR ) {
	    if( client.fd < 0 ) {
		mdicid = udicid = 0;
		return( -1 );
	    }
	    return( 0 );
	}
    }
    return( i );
}


int
#if NeedFunctionPrototypes
sj3_getdouon_mb( u_char *yomi, SJ3_DOUON *dou )
#else /* NeedFunctionPrototypes */
sj3_getdouon_mb( yomi, dou )
    u_char	*yomi;
    SJ3_DOUON *dou;
#endif /* NeedFunctionPrototypes */
{
#ifndef __sony_news
    if( _sys_code == SYS_NOTDEF )
	_sys_code = set_sys_code();
#endif
    if( _sys_code == SYS_EUC )
	return( sj3_getdouon_euc( yomi, dou ) );
    else
	return( sj3_getdouon( yomi, dou ) );
}


int
#if NeedFunctionPrototypes
sj3_gakusyuu( SJ3_STUDYREC *dcid )
#else /* NeedFunctionPrototypes */
sj3_gakusyuu( dcid )
    SJ3_STUDYREC	*dcid;
#endif /* NeedFunctionPrototypes */
{
    if( sj3_tango_gakusyuu( &client, dcid ) == SJ3ERROR ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return( 1 );
    }
    return( 0 );
}


int
#if NeedFunctionPrototypes
sj3_gakusyuu2( u_char *yomi1, u_char *yomi2, SJ3_STUDYREC *dcid )
#else /* NeedFunctionPrototypes */
sj3_gakusyuu2( yomi1, yomi2, dcid )
    u_char		*yomi1;
    u_char		*yomi2;
    SJ3_STUDYREC	*dcid;
#endif /* NeedFunctionPrototypes */
{
    if( sj3_bunsetu_gakusyuu( &client, yomi1, yomi2, dcid, MBCODE_SJIS )
	== SJ3ERROR ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return( 1 );
    }
    return( 0 );
}


static int
#if NeedFunctionPrototypes
sj3_gakusyuu2_euc( u_char *yomi1, u_char *yomi2, SJ3_STUDYREC *dcid )
#else /* NeedFunctionPrototypes */
sj3_gakusyuu2_euc( yomi1, yomi2, dcid )
    u_char		*yomi1;
    u_char		*yomi2;
    SJ3_STUDYREC	*dcid;
#endif /* NeedFunctionPrototypes */
{
    int		 flag;
    u_char	*y1p, *y2p;

    if( client.svr_version == 1 ) {
	defuse = 0;
	y1p = (u_char *)Euc2Sjis( (char *)yomi1 );
	if( y1p[0] == '\0' )
	    return( 1 );
	strcpy( (char *)buf1, (char *)y1p );
	y1p = buf1;
	defuse = 0;
	y2p = (u_char *)Euc2Sjis( (char *)yomi2 );
	if( yomi2  &&  yomi2[0] != '\0'  &&  y2p[0] == '\0' )
	    return( 1 );
	flag = MBCODE_SJIS;
    }
    else {
	y1p = yomi1;
	y2p = yomi2;
	flag = MBCODE_EUC;
    }
    if( sj3_bunsetu_gakusyuu( &client, y1p, y2p, dcid, flag ) == SJ3ERROR ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return( 1 );
    }
    return( 0 );
}


int
#if NeedFunctionPrototypes
sj3_gakusyuu2_mb( u_char *yomi1, u_char *yomi2, SJ3_STUDYREC *dcid )
#else /* NeedFunctionPrototypes */
sj3_gakusyuu2_mb( yomi1, yomi2, dcid )
    u_char		*yomi1;
    u_char		*yomi2;
    SJ3_STUDYREC	*dcid;
#endif /* NeedFunctionPrototypes */
{
#ifndef __sony_news
    if( _sys_code == SYS_NOTDEF )
	_sys_code = set_sys_code();
#endif
    if( _sys_code == SYS_EUC )
	return( sj3_gakusyuu2_euc( yomi1, yomi2, dcid ) );
    else
	return( sj3_gakusyuu2( yomi1, yomi2, dcid ) );
}


int
#if NeedFunctionPrototypes
sj3_touroku( u_char *yomi, u_char *kanji, int code )
#else /* NeedFunctionPrototypes */
sj3_touroku( yomi, kanji, code )
    u_char	*yomi;
    u_char	*kanji;
    int		 code;
#endif /* NeedFunctionPrototypes */
{
    if( sj3_tango_touroku( &client, udicid, yomi, kanji, code, MBCODE_SJIS ) ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	switch( sj3_error_number ) {
	  case SJ3_NoSuchDict:
	  case SJ3_ReadOnlyDict:	return( SJ3_DICT_ERROR );
	  case SJ3_DictLocked:		return( SJ3_DICT_LOCKED );
	  case SJ3_BadYomiString:	return( SJ3_BAD_YOMI_STR );
	  case SJ3_BadKanjiString:	return( SJ3_BAD_KANJI_STR );
	  case SJ3_BadHinsiCode:	return( SJ3_BAD_HINSI_CODE );
	  case SJ3_AlreadyExistWord:	return( SJ3_WORD_EXIST );
	  case SJ3_NoMoreDouonWord:	return( SJ3_DOUON_FULL );
	  case SJ3_NoMoreUserDict:	return( SJ3_DICT_FULL );
	  case SJ3_NoMoreIndexBlock:	return( SJ3_INDEX_FULL );
	  default:			return( SJ3_TOUROKU_FAILED );
	}
    }

    return( 0 );
}


static int
#if NeedFunctionPrototypes
sj3_touroku_euc( u_char *yomi, u_char *kanji, int code )
#else /* NeedFunctionPrototypes */
sj3_touroku_euc( yomi, kanji, code )
    u_char	*yomi;
    u_char	*kanji;
    int		 code;
#endif /* NeedFunctionPrototypes */
{
    int		 flag;
    u_char	*yp;
    u_char	*kp;

    if( client.svr_version == 1 ) {
	defuse = 0;
	yp = (u_char *)Euc2Sjis( (char *)yomi );
	if( yp[0] == '\0' )
	    return( SJ3_BAD_YOMI_STR );
	strcpy( (char *)buf1, (char *)yp );
	yp = buf1;
	kp = (u_char *)Euc2Sjis( (char *)kanji );
	if( kp[0] == '\0' )
	    return( SJ3_BAD_KANJI_STR );
	flag = MBCODE_SJIS;
    }
    else {
	yp = yomi;
	kp = kanji;
	flag = MBCODE_EUC;
    }
    if( sj3_tango_touroku( &client, udicid, yp, kp, code, flag ) ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	switch( sj3_error_number ) {
	  case SJ3_NoSuchDict:
	  case SJ3_ReadOnlyDict:	return( SJ3_DICT_ERROR );
	  case SJ3_DictLocked:		return( SJ3_DICT_LOCKED );
	  case SJ3_BadYomiString:	return( SJ3_BAD_YOMI_STR );
	  case SJ3_BadKanjiString:	return( SJ3_BAD_KANJI_STR );
	  case SJ3_BadHinsiCode:	return( SJ3_BAD_HINSI_CODE );
	  case SJ3_AlreadyExistWord:	return( SJ3_WORD_EXIST );
	  case SJ3_NoMoreDouonWord:	return( SJ3_DOUON_FULL );
	  case SJ3_NoMoreUserDict:	return( SJ3_DICT_FULL );
	  case SJ3_NoMoreIndexBlock:	return( SJ3_INDEX_FULL );
	  default:			return( SJ3_TOUROKU_FAILED );
	}
    }

    return( 0 );
}


int
#if NeedFunctionPrototypes
sj3_touroku_mb( u_char *yomi, u_char *kanji, int code )
#else /* NeedFunctionPrototypes */
sj3_touroku_mb( yomi, kanji, code )
    u_char	*yomi;
    u_char	*kanji;
    int		 code;
#endif /* NeedFunctionPrototypes */
{
#ifndef __sony_news
    if( _sys_code == SYS_NOTDEF )
	_sys_code = set_sys_code();
#endif
    if( _sys_code == SYS_EUC )
	return( sj3_touroku_euc( yomi, kanji, code ) );
    else
	return( sj3_touroku( yomi, kanji, code ) );
}


int
#if NeedFunctionPrototypes
sj3_syoukyo( u_char *yomi, u_char *kanji, int code )
#else /* NeedFunctionPrototypes */
sj3_syoukyo( yomi, kanji, code )
    u_char	*yomi;
    u_char	*kanji;
    int		 code;
#endif /* NeedFunctionPrototypes */
{
    if( sj3_tango_sakujo( &client, udicid, yomi, kanji, code, MBCODE_SJIS ) ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	switch( sj3_error_number ) {
	  case SJ3_NoSuchDict:
	  case SJ3_ReadOnlyDict:	return( SJ3_DICT_ERROR );
	  case SJ3_DictLocked:		return( SJ3_DICT_LOCKED );
	  case SJ3_BadYomiString:	return( SJ3_BAD_YOMI_STR );
	  case SJ3_BadKanjiString:	return( SJ3_BAD_KANJI_STR );
	  case SJ3_BadHinsiCode:	return( SJ3_BAD_HINSI_CODE );
	  case SJ3_NoSuchWord:		return( SJ3_WORD_NOT_EXIST );
	  default:			return( SJ3_SYOUKYO_FAILED );
	}
    }
    return( 0 );
}


static int
#if NeedFunctionPrototypes
sj3_syoukyo_euc( u_char *yomi, u_char *kanji, int code )
#else /* NeedFunctionPrototypes */
sj3_syoukyo_euc( yomi, kanji, code )
    u_char	*yomi;
    u_char	*kanji;
    int		 code;
#endif /* NeedFunctionPrototypes */
{
    int		 flag;
    u_char	*yp, *kp;

    if( client.svr_version == 1 ) {
	defuse = 0;
	yp = (u_char *)Euc2Sjis( (char *)yomi );
	if( yp[0] == '\0' )
	    return( SJ3_BAD_YOMI_STR );
	strcpy( (char *)buf1, (char *)yp );
	yp = buf1;
	kp = (u_char *)Euc2Sjis( (char *)kanji );
	if( kp[0] == '\0' )
	    return( SJ3_BAD_KANJI_STR );
	flag = MBCODE_SJIS;
    }
    else {
	yp = yomi;
	kp = kanji;
	flag = MBCODE_EUC;
    }
    if( sj3_tango_sakujo( &client, udicid, yp, kp, code, flag ) ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	switch( sj3_error_number ) {
	  case SJ3_NoSuchDict:
	  case SJ3_ReadOnlyDict:	return( SJ3_DICT_ERROR );
	  case SJ3_DictLocked:		return( SJ3_DICT_LOCKED );
	  case SJ3_BadYomiString:	return( SJ3_BAD_YOMI_STR );
	  case SJ3_BadKanjiString:	return( SJ3_BAD_KANJI_STR );
	  case SJ3_BadHinsiCode:	return( SJ3_BAD_HINSI_CODE );
	  case SJ3_NoSuchWord:		return( SJ3_WORD_NOT_EXIST );
	  default:			return( SJ3_SYOUKYO_FAILED );
	}
    }
    return( 0 );
}


int
#if NeedFunctionPrototypes
sj3_syoukyo_mb( u_char *yomi, u_char *kanji, int code )
#else /* NeedFunctionPrototypes */
sj3_syoukyo_mb( yomi, kanji, code )
    u_char	*yomi;
    u_char	*kanji;
    int		 code;
#endif /* NeedFunctionPrototypes */
{
#ifndef __sony_news
    if( _sys_code == SYS_NOTDEF )
	_sys_code = set_sys_code();
#endif
    if( _sys_code == SYS_EUC )
	return( sj3_syoukyo_euc( yomi, kanji, code ) );
    else
	return( sj3_syoukyo( yomi, kanji, code ) );
}


int
#if NeedFunctionPrototypes
sj3_getdict( u_char *buf )
#else /* NeedFunctionPrototypes */
sj3_getdict( buf )
    u_char	*buf;
#endif /* NeedFunctionPrototypes */
{
    if( sj3_tango_syutoku( &client, udicid, buf, MBCODE_SJIS ) ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return( 1 );
    }
    return( 0 );
}


static int
#if NeedFunctionPrototypes
sj3_getdict_euc( u_char *buf )
#else /* NeedFunctionPrototypes */
sj3_getdict_euc( buf )
    u_char	*buf;
#endif /* NeedFunctionPrototypes */
{
    int		 l, slen;
    char	*kp;

    if( client.svr_version == 1 ) {
	if( sj3_tango_syutoku( &client, udicid, buf, MBCODE_SJIS ) ) {
	    if( client.fd < 0 ) {
		mdicid = udicid = 0;
		return( -1 );
	    }
	    return( 1 );
	}

	slen = strlen( (char *)buf ) + 1;
	kp = Sjis2Euc( (char *)buf );
	if( kp[0] == '\0' )
	    return( 1 );
	strcpy( (char *)kbuf, kp );
	l = strlen( kp ) + 1;
	kp = Sjis2Euc( (char *)&buf[slen] );
	if( kp[0] == '\0' )
	    return( 1 );
	strcpy( (char *)&kbuf[l], kp );
	l += strlen( (char *)&kbuf[l] ) + 1;
	slen += strlen( (char *)&buf[slen] ) + 1;

	memcpy( &kbuf[l], &buf[slen], 4 );
	l += 4;
	memcpy( buf, kbuf, l );
    }
    else {
	if( sj3_tango_syutoku( &client, udicid, buf, MBCODE_EUC ) ) {
	    if( client.fd < 0 ) {
		mdicid = udicid = 0;
		return( -1 );
	    }
	    return( 1 );
	}
    }
    return( 0 );
}


int
#if NeedFunctionPrototypes
sj3_getdict_mb( u_char *buf )
#else /* NeedFunctionPrototypes */
sj3_getdict_mb( buf )
    u_char	*buf;
#endif /* NeedFunctionPrototypes */
{
#ifndef __sony_news
    if( _sys_code == SYS_NOTDEF )
	_sys_code = set_sys_code();
#endif
    if( _sys_code == SYS_EUC )
	return( sj3_getdict_euc( buf ) );
    else
	return( sj3_getdict( buf ) );
}


int
#if NeedFunctionPrototypes
sj3_nextdict( u_char *buf )
#else /* NeedFunctionPrototypes */
sj3_nextdict( buf )
    u_char	*buf;
#endif /* NeedFunctionPrototypes */
{
    if( sj3_tango_jikouho( &client, udicid, buf, MBCODE_SJIS ) ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return( 1 );
    }
    return( 0 );
}


static int
#if NeedFunctionPrototypes
sj3_nextdict_euc( u_char *buf )
#else /* NeedFunctionPrototypes */
sj3_nextdict_euc( buf )
    u_char	*buf;
#endif /* NeedFunctionPrototypes */
{
    int		 l, ll, slen;
    char	*kp;

    if( client.svr_version == 1 ) {
	if( sj3_tango_jikouho( &client, udicid, buf, MBCODE_SJIS ) ) {
	    if( client.fd < 0 ) {
		mdicid = udicid = 0;
		return( -1 );
	    }
	    return( 1 );
	}

	slen = strlen( (char *)buf ) + 1;
	kp = Sjis2Euc( (char *)buf );
	if( kp[0] == '\0' )
	    return( 1 );
	strcpy( (char *)kbuf, kp );
	l = strlen( kp ) + 1;
	kp = Sjis2Euc( (char *)&buf[slen] );
	if( kp[0] == '\0' )
	    return( 1 );
	strcpy( (char *)&kbuf[l], kp );
	slen += strlen( (char *)&buf[slen] ) + 1;
	l += strlen( (char *)&kbuf[l] ) + 1;
	memcpy( &kbuf[l], &buf[slen], 4 );
	l += 4;
	memcpy( buf, kbuf, l );
    }
    else {
	if( sj3_tango_jikouho( &client, udicid, buf, MBCODE_EUC ) ) {
	    if( client.fd < 0 ) {
		mdicid = udicid = 0;
		return( -1 );
	    }
	    return( 1 );
	}
    }
    return( 0 );
}


int
#if NeedFunctionPrototypes
sj3_nextdict_mb( u_char *buf )
#else /* NeedFunctionPrototypes */
sj3_nextdict_mb( buf )
    u_char	*buf;
#endif /* NeedFunctionPrototypes */
{
#ifndef __sony_news
    if( _sys_code == SYS_NOTDEF )
	_sys_code = set_sys_code();
#endif
    if( _sys_code == SYS_EUC )
	return( sj3_nextdict_euc( buf ) );
    else
	return( sj3_nextdict( buf ) );
}


int
#if NeedFunctionPrototypes
sj3_lockserv( void )
#else /* NeedFunctionPrototypes */
sj3_lockserv()
#endif /* NeedFunctionPrototypes */
{
    if( sj3_lock_server( &client ) == SJ3ERROR ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return( 1 );
    }
    return( 0 );
}


int
#if NeedFunctionPrototypes
sj3_unlockserv( void )
#else /* NeedFunctionPrototypes */
sj3_unlockserv()
#endif /* NeedFunctionPrototypes */
{
    if( sj3_unlock_server( &client ) ) {
	if( client.fd < 0 ) {
	    mdicid = udicid = 0;
	    return( -1 );
	}
	return( 1 );
    }
    return( 0 );
}
