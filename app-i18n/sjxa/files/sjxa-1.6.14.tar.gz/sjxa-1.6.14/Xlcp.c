/* $SonyId: Xlcp.c,v 1.7 1997/03/25 04:48:32 makoto Exp $ */
/******************************************************************

Copyright (c) 1992-1997  Sony Corporation

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL SONY CORPORATION BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of Sony Corporation shall
not be used in advertising or otherwise to promote the sale, use or ot
her dealings in this Software without prior written authorization from
Sony Corporation.

******************************************************************/
#ifdef	USE_XLC
#include	<stdio.h>
#include	<stdlib.h>
#include	<X11/Xlib.h>
#include	<X11/Xlibint.h>
#include	<X11/Xatom.h>
#include	<X11/keysym.h>
#include	<X11/Intrinsic.h>
#include	<Xmw/Label.h>
#include	<Xmw/List.h>
#include	<Xmw/TextOut.h>
#include	<Xmw/Preedit.h>
#include	<Xmw/StsArea.h>
#include	"XlcpP.h"
#include	"sjxa.h"
#include	"resource.h"
#include	"SjBuffer.h"
#include	"SjString.h"

#define	ON	1
#define	OFF	0

static int		 id = 0;
static int		 xlc_count = 0;
static PropertyQueue	*property_queue = NULL;
static Atom		 xlcp_selection;
static Atom		 kinput2_selection;
static Atom		 conversion_request;
static Atom		 conversion_notify;
static Atom		 conversion_end_request;
static Atom		 conversion_end;
static Atom		 conversion_close;
static Atom		 conversion_property;
static Atom		 conversion_attribute_notify;
static Atom		 conversion_inplace;
static Atom		 conversion_profile;
static Atom		 conversion_attribute_type;
static Atom		 compound_text;

extern Buffer		 root_window;
extern Sjxa		 resources;
extern Widget		 TopLevel, RootText, RootTextField;
extern Widget		 RootLabel, Box[];
extern Buffer		*buffer;
extern char		*program_name;
extern unsigned long	 default_foreground;
extern unsigned long	 default_background;
extern int		*depths;

extern void		 function_activate();
static void		 procNoEventMask();


static PropertyQueue *
#if NeedFunctionPrototypes
search_client_window( Window w )
#else
search_client_window( w )
    Window	w;
#endif
{
    PropertyQueue	*p;

    for( p = property_queue; p != NULL; p = p->next )
	if( p->client_window == w  ||  p->input_window == w  ||
	    ((p->buffer->conversion_style &
	      (XIMPreeditPosition | XIMPreeditArea))  &&
	      XtWindow(p->buffer->preedit_widget) == w) )
	    return( p );
    return( NULL );
}


static char *
#if NeedFunctionPrototypes
fontid2xlfd( Display *display, Font fid )
#else
fontid2xlfd( display, fid )
    Display	*display;
    Font	 fid;
#endif
{
    XFontStruct	*fs;
    XFontProp	*fp;
    int		 ii;
    char	*ss = NULL;
    Atom	 font;

    font = XInternAtom( display, "FONT", False );

    if( fid != NULL ) {
	fs = XQueryFont( display, fid );
	for( ii = 0, fp = fs->properties; ii < fs->n_properties;
	     ii++, fp++ ) {
	    if( fp->name == font ) {
		ss = XGetAtomName( display, fp->card32 );
		break;
	    }
	}
	XFreeFontInfo( NULL, fs, 1 );
    }
    return( ss );
}


static void
#if NeedFunctionPrototypes
XlcpConversion( int s )
#else
XlcpConversion( s )
    int		 s;
#endif
{
    Display	*display = XtDisplay( TopLevel );
    Window	 window = XtWindow( TopLevel );
    Atom	 prop;
    static int	 status = ON;

    if( status == s )
	return;
    status = s;
    prop = XInternAtom( display, CONVERSION_STATUS, False );
    XChangeProperty( display, window, prop, XA_INTEGER, 32,
		     PropModeReplace, (unsigned char *)&s, 1 );
}


static void
#if NeedFunctionPrototypes
SendConversionEnd( PropertyQueue *p )
#else
SendConversionEnd( p )
    PropertyQueue	*p;
#endif
{
    XClientMessageEvent	event;

    event.type = ClientMessage;
    event.display = XtDisplay(TopLevel);
    event.window = p->client_window;
    event.send_event = True;
    event.message_type = conversion_end;
    event.format = 32;
    event.data.l[0] = p->selection;
    event.data.l[1] = XtWindow(TopLevel);
    XSendEvent( XtDisplay(TopLevel), p->client_window, False, NULL,
		(XEvent *)&event ); 
}



static void
#if NeedFunctionPrototypes
xlcp_start( PropertyQueue *p )
#else
xlcp_start( p )
    PropertyQueue	*p;
#endif
{
    if( !p->conversion_close_flag ) {
	RootWindowMap( p->buffer, p->buffer->conversion_style );
	xlc_count++;
	XlcpConversion( ON );
    }
    else
	p->conversion_close_flag = False;
}


static Boolean
#if NeedFunctionPrototypes
xlcp_end( Display *display, Window w )
#else
xlcp_end( display, w )
    Display	*display;
    Window	 w;
#endif
{
    PropertyQueue	*p;

    if( (p = search_client_window( w )) == NULL  ||  !p->connect_flag )
	return( False );
    if( p->buffer->state & DELETE )
	sakujo_cancel( (Widget)NULL, (caddr_t)p->buffer, (caddr_t)NULL );
    if( p->buffer->state & CODE )
	code_cancel( (Widget)NULL, (caddr_t)p->buffer, (caddr_t)NULL );
    if( p->buffer->state & ADD )
	touroku_cancel( (Widget)NULL, (caddr_t)p->buffer, (caddr_t)NULL );
    if( p->buffer->state & SERVER )
	reconnect_cancel( (Widget)NULL, (caddr_t)p->buffer, (caddr_t)NULL );
    if( p->buffer->state & SELECT ) {
	if( p->buffer->conversion_style ==
	    (XIMPreeditNothing | XIMStatusNothing) )
	    XtUnmapWidget( RootTextField );
	else if( p->buffer->conversion_style & XIMPreeditPosition )
	    select_dialog_cancel( (Widget)NULL, (caddr_t)p->buffer,
				  (caddr_t)NULL );
    }
    if( p->buffer->state & EDIT )
	edit_cancel( p->buffer );
    if( p->buffer->state & (WRAP | CONVERSION) )
	henkan_cancel( p->buffer );

    if( !p->conversion_close_flag ) {
	xlc_count--;
	RootWindowUnmap( p->buffer->conversion_style );
	if( xlc_count == 0 )
	    XlcpConversion( OFF );
    }
    if( p->input_window )
	XUnmapWindow( display, p->input_window );
    if( p->buffer->conversion_style & XIMPreeditPosition )
	XmwPreeditUnmapWidget( p->buffer->preedit_widget );
    SendConversionEnd( p );
    p->connect_flag = False;
    p->buffer->connect--;

    return( True );
}


Boolean
#if NeedFunctionPrototypes
xlcp_all_end( Window w )
#else
xlcp_all_end( w )
    Window	w;
#endif
{
    PropertyQueue	*p;

    if( w != NULL  &&  search_client_window( w ) == NULL )
	return( False );
    for( p = property_queue; p != NULL; p = p->next ) {
	if( p->connect_flag ) {
	    p->conversion_close_flag = False;
	    xlcp_end( XtDisplay(TopLevel), p->client_window );
	}
	else if( p->conversion_close_flag ) {
	    p->conversion_close_flag = False;
	    xlc_count--;
	    RootWindowUnmap( p->buffer->conversion_style );
	    if( xlc_count == 0 )
		XlcpConversion( OFF );
	}
    }
    return( True );
}



static void
#if NeedFunctionPrototypes
SendConversionNotify( register PropertyQueue *p )
#else
SendConversionNotify( p )
    register PropertyQueue	*p;
#endif
{
    XClientMessageEvent	event;

    event.type = ClientMessage;
    event.display = XtDisplay(TopLevel);
    event.window = p->client_window;
    event.send_event = True;
    event.message_type = conversion_notify;
    event.format = 32;
    event.data.l[0] = p->selection;
    event.data.l[1] = p->client_text;
    event.data.l[2] = p->client_property;
    event.data.l[3] = p->input_window ? p->input_window
				      : XtWindow(p->buffer->preedit_widget);
    event.data.l[4] = ISXlcp(p) ? p->client_inplace : None;
    XSendEvent( XtDisplay(TopLevel), p->client_window, False, NULL,
		(XEvent *)&event );
}



static void
#if NeedFunctionPrototypes
set_attribute( Display *display, PropertyQueue *p, long *data, int items )
#else /* NeedFunctionPrototypes */
set_attribute( display, p, data, items )
    Display		*display;
    PropertyQueue	*p;
    long		*data;
    int			 items;
#endif /* NeedFunctionPrototypes */
{
    int			  l, n, m, ii, len;
    char		  name[20];
    Arg			  pargs[20], sargs[20];
    long		  input_style = XIMPreeditNothing;
    long		  event_capture_method = INPUT_ONLY_WINDOW_EVENT;
    unsigned long	  mask = 0;
    XWindowAttributes	  attr;
    char		 *font0, *font1;
    XFontSet		  fs;
    XFontStruct		**fsl;
    char		**fn;
    XPoint		  spot_location;
    XRectangle		  client_area;
    XRectangle		  status_area;
    unsigned long	  lbg;

    if( p->buffer == NULL ) {
	for( n = 0; n < items; n += len ) {
	    len = data[n] & 0xffff;
	    if( (data[n] >> 16) < 16 )
		mask |= 1 << (data[n] >> 16);
	    switch( data[n++] >> 16 ) {
	      case INPUT_STYLE_MASK:
		switch( data[n] ) {
		  case ROOT_WINDOW_STYLE:
#ifdef DEBUG
		    if( resources.debug & 4 )
			puts( " INPUT_STYLE (root window style)" );
#endif
		    input_style = XIMPreeditNothing;
		    break;

		  case OFF_THE_SPOT_STYLE:
#ifdef DEBUG
		    if( resources.debug & 4 )
			puts( " INPUT_STYLE (off the spot style)" );
#endif
		    input_style = XIMPreeditArea;
		    break;

		  case OVER_THE_SPOT_STYLE:
#ifdef DEBUG
		    if( resources.debug & 4 )
			puts( " INPUT_STYLE (over the spot style)" );
#endif
		    input_style = XIMPreeditPosition;
		    break;
		}
		break;

	      case EVENT_CAPTURE_METHOD_MASK:
#ifdef DEBUG
		    if( resources.debug & 4 ) {
			printf( " EVENT_CAPTURE_METHOD " );
			switch( data[n] ) {
			  case 0:
			    puts( "(send event)" );
			    break;
			  case 1:
			    puts( "(input only window event)" );
			    break;
			  case 2:
			    puts( "(select input event)" );
			    break;
			}
		    }
#endif
		event_capture_method = data[n];
		break;
	    }
	}

	p->kinput2 = (Kinput2Info *)calloc( 1, sizeof(Kinput2Info) );
	p->kinput2->event_capture_method = event_capture_method;
	switch( input_style ) {
	  case XIMPreeditNothing:
	    p->buffer = &root_window;
	    break;

	  case XIMPreeditPosition:
	  case XIMPreeditArea:
	    p->buffer = buffer_alloc();
	    p->buffer->conversion_style = input_style;
	    if( mask & (1 << STATUS_AREA_MASK) )
		p->buffer->conversion_style |= XIMStatusArea;
	    else
		p->buffer->conversion_style |= XIMStatusNothing;
	    break;
	}
    }

    if( p->kinput2 ) {
	for( l = n = m = 0; l < items; l += len ) {
	    len = data[l] & 0xffff;
	    if( (data[l] >> 16) < 16 )
		mask |= 1 << (data[l] >> 16);
	    switch( data[l++] >> 16 ) {
	      case FOCUS_WINDOW_MASK:
		p->kinput2->focus_window = data[l];
		XtSetArg( pargs[m], XmwNfocusWindow, p->kinput2->focus_window );
		m++;
		XtSetArg( sargs[n], XmwNfocusWindow, p->kinput2->focus_window );
		n++;
#ifdef DEBUG
		if( resources.debug & 4 )
		    printf( " FOCUS_WINDOW %08x\n", data[l] );
#endif
		break;

	      case SPOT_LOCATION_MASK:
		spot_location.x = data[l] >> 16;
		spot_location.y = data[l] & 0xffff;
		XtSetArg( pargs[m], XmwNspotLocationX, spot_location.x );
		m++;
#ifdef DEBUG
		if( resources.debug & 4 )
		    printf( " SPOT_LOCATION (%d,%d)\n",
			    spot_location.x, spot_location.y );
#endif
		break;

	      case CLIENT_AREA_MASK:
		client_area.x = data[l] >> 16;
		client_area.y = data[l] & 0xffff;
		client_area.width = data[l+1] >> 16;
		client_area.height = data[l+1] & 0xffff;
		XtSetArg( pargs[m], XmwNareaX, client_area.x );		m++;
		XtSetArg( pargs[m], XmwNareaY, client_area.y );		m++;
		XtSetArg( pargs[m], XmwNareaWidth, client_area.width );	m++;
		XtSetArg( pargs[m], XmwNareaHeight, client_area.height );
		m++;
#ifdef DEBUG
		if( resources.debug & 4 )
		    printf( " CLIENT_AREA (%d,%d) %dx%d\n",
			    client_area.x, client_area.y,
			    client_area.width, client_area.height );
#endif
		break;

	      case STATUS_AREA_MASK:
		status_area.x = data[l] >> 16;
		status_area.y = data[l] & 0xffff;
		status_area.width = data[l+1] >> 16;
		status_area.height = data[l+1] & 0xffff;
		XtSetArg( sargs[n], XmwNareaX, status_area.x );		n++;
		XtSetArg( sargs[n], XmwNareaY, status_area.y );		n++;
		XtSetArg( sargs[n], XmwNareaWidth, status_area.width );	n++;
		XtSetArg( sargs[n], XmwNareaHeight, status_area.height );
		n++;
#ifdef DEBUG
		if( resources.debug & 4 )
		    printf( " CLIENT_AREA (%d,%d) %dx%d\n",
			    status_area.x, status_area.y,
			    status_area.width, status_area.height );
#endif
		break;

	      case COLORMAP_MASK:
#ifdef DEBUG
		if( resources.debug & 4 )
		    puts( " COLORMAP" );
#endif
		p->kinput2->colormap = data[l];
		XtSetArg( pargs[m], XtNcolormap, p->kinput2->colormap );
		m++;
		XtSetArg( sargs[n], XtNcolormap, p->kinput2->colormap );
		n++;
		break;

	      case COLOR_MASK:
#ifdef DEBUG
		if( resources.debug & 4 )
		    printf( " COLOR (fg=%d bg=%d)\n", data[l], data[l+1] );
#endif
		p->kinput2->foreground = data[l];
		p->kinput2->background = data[l+1];
		XtSetArg( pargs[m], XtNforeground, data[l] );		m++;
		XtSetArg( sargs[n], XtNforeground, data[l] );		n++;
		XtSetArg( pargs[m], XtNbackground, data[l+1] );		m++;
		XtSetArg( sargs[n], XtNbackground, data[l+1] );		n++;
		break;

	      case BG_PIXMAP_MASK:
#ifdef DEBUG
		if( resources.debug & 4 )
		    puts( " BACKGROUND_PIXMAP" );
#endif
		p->kinput2->pixmap = data[l];
		XtSetArg( pargs[m], XtNbackgroundPixmap, data[l] );	n++;
		XtSetArg( sargs[n], XtNbackgroundPixmap, data[l] );	n++;
		break;

	      case LINE_SPACING_MASK:
		XtSetArg( pargs[m], XmwNlineSpacing, data[l] );		m++;
#ifdef DEBUG
		if( resources.debug & 4 )
		    printf( " LINE_SPACING %d\n", data[l] );
#endif
		break;

	      case FONT_ATOM_MASK:
		for( ii = 0, font0 = NULL; ii < len; ii++ ) {
		    if( (font1 = XGetAtomName( display, data[l+ii] )) == NULL )
			continue;
		    if( font0 == NULL )
			font0 = font1;
		    else {
			font0 = (char *)Xrealloc( font0,
					    strlen(font0) + strlen(font1) + 2 );
			strcat( font0, "," );
			strcat( font0, font1 );
			XFree( font1 );
		    }
		}
		fs = NULL;
		if( font0 ) {
		    if( (fs = string2fs( display, font0 )) != NULL ) {
			XtSetArg( pargs[m], XtNfontSet, fs );		m++;
			XtSetArg( sargs[n], XtNfontSet, fs );		n++;
			p->kinput2->font_set = fs;
			ii = XFontsOfFontSet( fs, &fsl, &fn );
			p->kinput2->ascent = 0;
			while( --ii >= 0 ) {
			    if( p->kinput2->ascent < fsl[ii]->ascent )
				p->kinput2->ascent = fsl[ii]->ascent;
			}
#ifdef DEBUG
			if( resources.debug & 4 )
			    printf( " FONT %s\n", font0 );
#endif
		    }
		}
		if( fs == NULL )
		    mask &= ~(1 << FONT_ATOM_MASK);
		break;

	      case CURSOR_MASK:
#ifdef DEBUG
		if( resources.debug & 4 )
		    puts( " CURSOR" );
#endif
		XtSetArg( pargs[m], XtNcursor, data[l] );		m++;
		XtSetArg( sargs[n], XtNcursor, data[l] );		n++;
		break;
	    }
	}

	if( p->buffer->conversion_style &
	    (XIMPreeditPosition | XIMPreeditArea) ) {
	    if( p->buffer->preedit_widget == NULL ) {
		if( p->kinput2->focus_window == None ) {
		    XtSetArg( pargs[m], XmwNfocusWindow, p->client_window );
		    m++;
		    p->kinput2->focus_window = p->client_window;
		}

		XGetWindowAttributes( display, p->kinput2->focus_window,
				      &attr );
		XtSetArg( pargs[m], XtNdepth, attr.depth );		m++;
		XtSetArg( pargs[m], XtNscreen, attr.screen );		m++;
		XtSetArg( pargs[m], XtNaccelerators,
			  resources.base_accelerators );		m++;

		if( (mask & (1 << SPOT_LOCATION_MASK))  &&
		    (mask & (1 << FONT_ATOM_MASK)) ) {
		    XtSetArg( pargs[m], XmwNspotLocationY,
			      spot_location.y - p->kinput2->ascent );	m++;
		}

		if( !(mask & (1 << CLIENT_AREA_MASK)) ) {
		    XtSetArg( pargs[m], XmwNareaX, 0 );			m++;
		    XtSetArg( pargs[m], XmwNareaY, 0 );			m++;
		    XtSetArg( pargs[m], XmwNareaWidth, attr.width );	m++;
		    XtSetArg( pargs[m], XmwNareaHeight, attr.height );	m++;
		}
		if( !(mask & (1 << COLORMAP_MASK)) ) {
		    XtSetArg( pargs[m], XtNcolormap,
			      DefaultColormapOfScreen(attr.screen) );	m++;
		}

		sprintf( name, "xlc_pre%08x", id++ );
		p->buffer->preedit_widget = XmwCreatePreedit( TopLevel, name,
							      pargs, m );
		XtAddEventHandler( p->buffer->preedit_widget, NoEventMask,
				   True, procNoEventMask, NULL );
		XtInstallAccelerators( p->buffer->preedit_widget,
				       p->buffer->preedit_widget );
		if( resources.accelerators ) {
		    XtOverrideTranslations( p->buffer->preedit_widget,
					    resources.accelerators );
		    XtInstallAccelerators( p->buffer->preedit_widget,
					   p->buffer->preedit_widget );
		}

		if( !(mask & (1 << FONT_ATOM_MASK)) ) {
		    XtVaGetValues( p->buffer->preedit_widget, XmwNascent,
				   &p->kinput2->ascent, NULL );
		    if( mask & (1 << SPOT_LOCATION_MASK) ) {
			XtVaSetValues( p->buffer->preedit_widget,
				       XmwNspotLocationY,
				       spot_location.y - p->kinput2->ascent,
				       NULL );
		    }
		}

		if( p->buffer->conversion_style & XIMStatusNothing ) {
		    p->buffer->label = RootLabel;
		    p->buffer->box[0] = Box[0];
		    p->buffer->box[1] = Box[1];
		}
	    }
	    else {
		if( mask & (1 << SPOT_LOCATION_MASK) ) {
		    XtSetArg( pargs[m], XmwNspotLocationY,
			      spot_location.y - p->kinput2->ascent );	m++;
		}
		XtSetValues( p->buffer->preedit_widget, pargs, m );
	    }
	}

	if( p->buffer->conversion_style & XIMStatusArea ) {
	    if( p->buffer->status_widget == NULL ) {
		if( !(mask & (1 << FOCUS_WINDOW_MASK)) ) {
		    XtSetArg( sargs[n], XmwNfocusWindow, p->client_window );
		    n++;
		    p->kinput2->focus_window = p->client_window;
		}

		XGetWindowAttributes( display, p->kinput2->focus_window,
				      &attr );
		XtSetArg( sargs[n], XtNdepth, attr.depth );		n++;
		XtSetArg( sargs[n], XtNscreen, attr.screen );		n++;
		XtSetArg( sargs[n], XtNaccelerators,
			  resources.base_accelerators );		n++;

		if( !(mask & (1 << CLIENT_AREA_MASK)) ) {
		    XtSetArg( sargs[n], XmwNareaX, 0 );			n++;
		    XtSetArg( sargs[n], XmwNareaY, 0 );			n++;
		    XtSetArg( sargs[n], XmwNareaWidth, attr.width );	n++;
		    XtSetArg( sargs[n], XmwNareaHeight, attr.height );	n++;
		}
		if( !(mask & (1 << COLORMAP_MASK)) ) {
		    p->kinput2->colormap = DefaultColormapOfScreen(attr.screen);
		    XtSetArg( sargs[n], XtNcolormap,
			      DefaultColormapOfScreen(attr.screen) );	n++;
		}
		if( !(mask & (1 << COLOR_MASK)) ) {
		    p->kinput2->foreground = default_foreground;
		    p->kinput2->background = default_background;
		    XtSetArg( sargs[n], XtNbackground, default_background );
		    n++;
		}

		sprintf( name, "xlc_sts%08x", id++ );
		p->buffer->status_widget =
		    XmwCreateManagedStatusArea( TopLevel, name, sargs, n );

		n = 0;
		m = XScreenNumberOfScreen( attr.screen );
		lbg = (depths[n] == 1) ? p->kinput2->background
				       : light_color( display,
						      p->kinput2->colormap,
						      p->kinput2->background );
		XtSetArg( sargs[n], XtNborderWidth, 0 );		n++;
		XtSetArg( sargs[n], XtNbackground, p->kinput2->background );
		n++;
		XtSetArg( sargs[n], XtNforeground, p->kinput2->foreground );
		n++;
		XtSetArg( sargs[n], XtNlabel, resources.sjxa );		n++;
		if( mask & (1 << BG_PIXMAP_MASK) ) {
		    XtSetArg( sargs[n], XtNbackgroundPixmap,
			      p->kinput2->pixmap );			n++;
		}
		if( mask & (1 << FONT_ATOM_MASK) ) {
		    XtSetArg( sargs[n], XtNfontSet, p->kinput2->font_set );
		    n++;
		}
		p->buffer->label =
		    XtCreateManagedWidget( "Label", labelWidgetClass,
					   p->buffer->status_widget,
					   sargs, n );

		if( p->buffer->conversion_style & XIMPreeditPosition ) {
		    n = 0;
		    if( mask & (1 << FONT_ATOM_MASK) ) {
			XtSetArg( sargs[n], XtNfontSet, p->kinput2->font_set );
			n++;
		    }
		    XtSetArg( sargs[n], XtNbackground, p->kinput2->background );
		    n++;
		    XtSetArg( sargs[n], XtNforeground, p->kinput2->foreground );
		    n++;
		    XtSetArg( sargs[n], XtNhorizDistance, 2 );		n++;
		    XtSetArg( sargs[n], XtNborderWidth, 0 );		n++;
		    XtSetArg( sargs[n], XtNmappedWhenManaged, False );	n++;
		    XtSetArg( sargs[n], XmwNitemBackground, lbg );	n++;
		    XtSetArg( sargs[n], XmwNitemCount, 5 );		n++;
		    XtSetArg( sargs[n], XmwNitemLength,
			      resources.function_par_length * 5 );	n++;
		    XtSetArg( sargs[n], XmwNitems, resources.function_items );
		    n++;
		    XtSetArg( sargs[n], XmwNnumRows, 5 );		n++;
		    XtSetArg( sargs[n], XmwNvisibleHorizontalItemCount, 5 );;
		    n++;
		    XtSetArg( sargs[n], XmwNvisibleVerticalItemCount, 1 );
		    n++;
		    p->buffer->box[0] = XmwCreateList( p->buffer->status_widget,
						       "LeftBox", sargs, n );
		    n = 0;
		    if( mask & (1 << FONT_ATOM_MASK) ) {
			XtSetArg( sargs[n], XtNfontSet, p->kinput2->font_set );
			n++;
		    }
		    XtSetArg( sargs[n], XtNbackground, p->kinput2->background );
		    n++;
		    XtSetArg( sargs[n], XtNforeground, p->kinput2->foreground );
		    n++;
		    XtSetArg( sargs[n], XtNhorizDistance, 2 );		n++;
		    XtSetArg( sargs[n], XtNborderWidth, 0 );		n++;
		    XtSetArg( sargs[n], XtNmappedWhenManaged, False );	n++;
		    XtSetArg( sargs[n], XmwNitemBackground, lbg );	n++;
		    XtSetArg( sargs[n], XmwNitemCount, 5 );		n++;
		    XtSetArg( sargs[n], XmwNitemLength,
			      resources.function_par_length * 5 );	n++;
		    XtSetArg( sargs[n], XmwNitems,
		      &resources.function_items[resources.function_par_length*5] );
		    n++;
		    XtSetArg( sargs[n], XmwNnumRows, 5 );		n++;
		    XtSetArg( sargs[n], XmwNvisibleHorizontalItemCount, 5 );;
		    n++;
		    XtSetArg( sargs[n], XmwNvisibleVerticalItemCount, 1 );
		    n++;
		    p->buffer->box[1] = XmwCreateList( p->buffer->status_widget,
						       "RightBox", sargs, n );
		    XtManageChildren( p->buffer->box, 2 );
		    XtAddCallback( p->buffer->box[0], XmwNsetCallback,
				   (XtCallbackProc)function_activate,
				   (caddr_t)p->buffer );
		    XtAddCallback( p->buffer->box[1], XmwNsetCallback,
				   (XtCallbackProc)function_activate,
				   (caddr_t)p->buffer );
		}
		XtMapWidget( p->buffer->status_widget );
	    }
	    else {
		XtSetValues( p->buffer->status_widget, sargs, n );

		n = 0;
		if( mask & (1 << COLOR_MASK) ) {
		    XtSetArg( sargs[n], XtNforeground, p->kinput2->foreground );
		    n++;
		    XtSetArg( sargs[n], XtNbackground, p->kinput2->background );
		    n++;
		}
		if( mask & (1 << BG_PIXMAP_MASK) ) {
		    XtSetArg( sargs[n], XtNbackgroundPixmap,
			      p->kinput2->pixmap );			n++;
		}
		if( mask & (1 << FONT_ATOM_MASK) ) {
		    XtSetArg( sargs[n], XtNfontSet, p->kinput2->font_set );
		    n++;
		}
		XtSetValues( p->buffer->label, sargs, n );

		if( p->buffer->conversion_style & XIMPreeditArea ) {
		    XtSetValues( p->buffer->box[0], sargs, n );
		    XtSetValues( p->buffer->box[1], sargs, n );
		}
	    }
	}
    }
}


static PropertyQueue *
#if NeedFunctionPrototypes
add_property_queue( Display *display, Atom selection, Window client, Atom text,
		    Atom property, Atom inplace )
#else /* NeedFunctionPrototypes */
add_property_queue( display, selection, client, text, property, inplace )
    Display	*display;
    Atom	 selection;
    Window	 client;
    Atom	 text, property, inplace;
#endif /* NeedFunctionPrototypes */
{
    PropertyQueue	*p1, *p2;
    int			 n, len;
    Atom		 actual_type;
    int			 actual_format;
    unsigned long	 nitems, bytes_after;
    long		*data;

    p1 = (PropertyQueue *)calloc( 1, sizeof(PropertyQueue) );

    for( p2 = property_queue; p2 != NULL; p2 = p2->next ) {
	if( p2->next == NULL ) {
	    p2->next = p1;
	    p1->previous = p2;
	    break;
	}
    }
    if( p2 == NULL )
	property_queue = p1;

    p1->selection = selection;
    p1->client_window = client;
    p1->client_text = text;
    p1->client_property = property;
    p1->client_inplace = inplace;

    p1->protocol = XLC_PROTOCOL;
    if( inplace == None ) {
	p1->buffer = &root_window;
    }
    else if ( inplace == conversion_inplace ) {
	p1->buffer = buffer_alloc();
	p1->buffer->conversion_style = XIMPreeditPosition
				     | XIMStatusNothing;
	p1->buffer->label = RootLabel;
	p1->buffer->box[0] = Box[0];
	p1->buffer->box[1] = Box[1];
	p1->info = (InplaceInfo *)calloc( 1, sizeof(InplaceInfo) );
    }
    else {
	p1->protocol = KINPUT2_PROTOCOL;
	XGetWindowProperty( display, client, inplace, 0, 10000, True,
			    AnyPropertyType, &actual_type, &actual_format,
			    &nitems, &bytes_after, (unsigned char **)&data );

	set_attribute( display, p1, data, nitems );
	XFree( data );
    }

    if( p1->protocol == XLC_PROTOCOL  ||
	p1->kinput2->event_capture_method == INPUT_ONLY_WINDOW_EVENT ) {
	p1->input_window = XCreateWindow( display, client, 0, 0, 10000, 10000,
					  0, 0, InputOnly, NULL, 0, NULL );
	XSelectInput( display, p1->input_window, KeyPressMask );
    }

    return( p1 );
}


static void
#if NeedFunctionPrototypes
ConversionRequest( XClientMessageEvent *event )
#else
ConversionRequest( event )
    XClientMessageEvent	*event;
#endif
{
    Display		*display = event->display;
    PropertyQueue	*p;
    Atom		 actual_type;
    int			 actual_format;
    unsigned long	 nitems, bytes_after;
    long		*data;

    if( (p = search_client_window( (Window)event->data.l[1] )) == NULL ) {
	if( IsRegisteredWindow( XLC_PROTOCOL, (Window)event->data.l[1], NULL ) )
	    return;
	if( (Atom)event->data.l[2] != compound_text )
	    return;

	p = add_property_queue( display, (Atom)event->data.l[0],
				(Window)event->data.l[1],
			        (Atom)event->data.l[2], (Atom)event->data.l[3],
			        (Atom)event->data.l[4] );

	XSelectInput( display, p->client_window, StructureNotifyMask );
    }
    else {
	if( (Atom)event->data.l[2] != compound_text )
	    return;

	p->client_property = event->data.l[3];
	p->client_inplace = event->data.l[4];

	if( ISKinput2(p)  &&
	    (p->buffer->conversion_style &
	     (XIMPreeditPosition | XIMPreeditArea)) ) {
	    XGetWindowProperty( display, p->client_window, event->data.l[4], 0,
				10000, True, AnyPropertyType, &actual_type,
				&actual_format, &nitems, &bytes_after,
				(unsigned char **)&data );
	    set_attribute( display, p, data, nitems );
	    XFree( data );
	}
    }

    if( p->client_property == NULL )
	p->client_property = conversion_property;
    if( !p->connect_flag ) {
	p->connect_flag = True;
	p->buffer->connect++;

	xlcp_start( p );
	if( p->input_window )
	    XMapWindow( display, p->input_window );
	if( (p->buffer->conversion_style &
	     (XIMPreeditPosition | XIMPreeditArea))  &&
	    p->buffer->preedit_widget ) {
	    XmwPreeditMapWidget( p->buffer->preedit_widget );
	    XtVaSetValues( p->buffer->preedit_widget, XmwNfocus, True, NULL );
	    buffer_initialize( p->buffer );
	}
	SendConversionNotify( p );
    }

    XFlush( display );
    set_buffer( p->buffer->preedit_widget, KeyPress );
}


static void
#if NeedFunctionPrototypes
ConversionEndRequest( XClientMessageEvent *event )
#else
ConversionEndRequest( event )
    XClientMessageEvent	*event;
#endif
{
    register PropertyQueue	*p;

    if( (p = search_client_window( (Window)event->data.l[1] )) != NULL  &&
       p->connect_flag )
	xlcp_end( event->display, p->client_window );
}


static void
#if NeedFunctionPrototypes
ConversionClose( XClientMessageEvent *event )
#else
ConversionClose( event )
    XClientMessageEvent	*event;
#endif
{
    register PropertyQueue	*p;
    Window			w;

    w = event->data.l[1];
    if( (p = search_client_window( w )) == NULL )
	return;
    if( p->connect_flag ) {
	p->conversion_close_flag = True;
	xlcp_end( event->display, p->client_window );
    }
}


static void
#if NeedFunctionPrototypes
ConversionAttributeNotify( XClientMessageEvent *event )
#else
ConversionAttributeNotify( event )
    XClientMessageEvent	*event;
#endif
{
    PropertyQueue	*p;
    Window		 w;
    Atom		 actual_type;
    int			 actual_format;
    unsigned long	 nitems, bytes_after;
    long		*data;

    w = event->data.l[1];
    if( (p = search_client_window( w )) == NULL )
	return;
    if( ISKinput2(p) ) {
	if( event->data.l[2] == 0x00010001 ) {
	    XGetWindowProperty( event->display, p->client_window,
				event->data.l[3], 0, 10000, True,
				AnyPropertyType, &actual_type, &actual_format,
				&nitems, &bytes_after,
				(unsigned char **)&data );
	    set_attribute( event->display, p, data, nitems );
	    XFree( data );
	}
	else
	    set_attribute( event->display, p, &event->data.l[2],
			   event->data.l[2] & 0xffff );
    }
}


static void
#if NeedFunctionPrototypes
proc_clientmsg( XClientMessageEvent *event )
#else
proc_clientmsg( event )
    XClientMessageEvent	*event;
#endif
{
#ifdef	DEBUG
    Window	w;

    w = event->data.l[1];
#endif
    if( event->message_type == conversion_request ) {
#ifdef	DEBUG
	if( resources.debug & 4 )
	    printf( "ConversionRequest [%x]\n", w );
#endif
	ConversionRequest( event );
    }
    else if( event->message_type == conversion_end_request ) {
#ifdef	DEBUG
	if( resources.debug & 4 )
	    printf( "ConversionEndRequest [%x]\n", w );
#endif
	if( property_queue != NULL );
	    ConversionEndRequest( event );
    }
    else if( event->message_type == conversion_close ) {
#ifdef	DEBUG
	if( resources.debug & 4 )
	    printf( "ConversionClose [%x]\n", w );
#endif
	ConversionClose( event );
    }
    else if( event->message_type == conversion_attribute_notify ) {
#ifdef	DEBUG
	if( resources.debug & 4 )
	    printf( "ConversionAttributeNotify [%x]\n", w );
#endif
	ConversionAttributeNotify( event );
    }
}


static void
#if NeedFunctionPrototypes
procNoEventMask( Widget w, XtPointer client_data, XEvent *event,
		 Boolean *continue_to_dispatch )
#else
procNoEventMask( w, client_data, event, continue_to_dispatch )
    Widget	 w;
    XtPointer	 client_data;
    XEvent	*event;
    Boolean	*continue_to_dispatch;
#endif
{
    switch( event->type ) {
      case SelectionClear:
	if( event->xselectionclear.selection == xlcp_selection  ||
	    event->xselectionclear.selection == kinput2_selection ) {
	    fprintf( stderr, "%s : selection clear event occured.\n\r",
		     program_name );
	    done();
	}
	break;

      case ClientMessage:
	proc_clientmsg( (XClientMessageEvent *)event );
	break;
    }
}


static void
#if NeedFunctionPrototypes
set_xlc_selection_owner( Display *d, Window w, Time time )
#else
set_xlc_selection_owner( d, w, time )
    Display	*d;
    Window	 w;
    Time	 time;
#endif
{
    xlcp_selection = XInternAtom( d, JAPANESE_CONVERSION, False );
    kinput2_selection = XInternAtom( d, _JAPANESE_CONVERSION, False );
    XSetSelectionOwner( d, xlcp_selection, w, time );
    XSetSelectionOwner( d, kinput2_selection, w, time );
}


static void
#if NeedFunctionPrototypes
XlcpPropertyChange( XPropertyEvent *event )
#else
XlcpPropertyChange( event )
    XPropertyEvent	*event;
#endif
{
    Display		*display = event->display;
    PropertyQueue	*p;
    Arg			 args[30];
    int			 n;
    Atom		 actual_type;
    int			 actual_format;
    unsigned long	 nitems, bytes_after;
    long		*prop;
    char		*font0, *font1;
    XWindowAttributes	 attr;
    XFontSet		 fs;
    char		*def_string;

    if( event->atom == conversion_inplace ) {
	XGetWindowProperty( display, event->window, conversion_inplace,
			    0, 10000, True, conversion_inplace,
			    &actual_type, &actual_format, &nitems, &bytes_after,
			    (unsigned char **)&prop );

	if( actual_type == None  &&  actual_format == 0  &&
	    bytes_after == 0 )
	    return;

	if( (p = search_client_window( prop[1] )) == NULL  ||
	   p->info == NULL ) {
	    XFree( prop );
	    return;
	}

	n = 0;
	p->info->in_flag = prop[0];
	p->info->in_win = prop[1];
	if( prop[0] & AllInformation ) {
	    p->info->in_attr.back = prop[2];
	    p->info->in_attr.border = prop[3];
	    p->info->in_attr.bwidth = prop[4];
	    p->info->in_draw.fore = prop[5];
	    p->info->in_draw.back = prop[6];
	    p->info->in_draw.font8 = prop[7];
	    p->info->in_draw.font16 = prop[8];
	    p->info->in_draw.efont16 = prop[9];

	    font0 = fontid2xlfd( display, prop[7] );
	    font1 = fontid2xlfd( display, prop[8] );
	    if( font0 != NULL ) {
		if( font1 != NULL ) {
		    font0 = realloc( font0, strlen(font0) + strlen(font1) + 2 );
		    strcat( font0, "," );
		    strcat( font0, font1 );
		    XFree( font1 );
		}
	    }
	    else {
		font0 = font1;
	    }

	    XtSetArg( args[n], XtNbackground, prop[2] );	n++;
	    XtSetArg( args[n], XtNborderColor, prop[3] );	n++;
	    XtSetArg( args[n], XtNborderWidth, prop[4] );	n++;
	    XtSetArg( args[n], XtNforeground, prop[5] );	n++;
	    if( font0 ) {
		fs = string2fs( display, font0 );
		if( fs != NULL ) {
		    XtSetArg( args[n], XtNfontSet, fs );	n++;
		}
		XFree( font0 );
	    }
	}
	if( prop[0] & (AllInformation | FrameInformation) ) {
	    p->info->in_frame.x = prop[10];
	    p->info->in_frame.y = prop[11];
	    p->info->in_frame.width = prop[12];
	    p->info->in_frame.height = prop[13];
	    p->info->in_frame.line_height = prop[16];

	    if( prop[12] == 0  ||  prop[13] == 0 ) {
		XGetWindowAttributes( display, prop[1], &attr );
		p->info->in_frame.width = prop[12] = attr.width;
		p->info->in_frame.height = prop[13] = attr.height;
	    }

	    XtSetArg( args[n], XmwNareaX, prop[10] );		n++;
	    XtSetArg( args[n], XmwNareaY, prop[11] );		n++;
	    XtSetArg( args[n], XmwNareaWidth, prop[12] );	n++;
	    XtSetArg( args[n], XmwNareaHeight, prop[13] );	n++;
	}
	if( prop[0] &
	    (AllInformation | FrameInformation | OffsetInformation) ) {
	    p->info->in_frame.x_off = prop[14];
	    p->info->in_frame.y_off = prop[15];

	    XtSetArg( args[n], XmwNspotLocationX, prop[14] );	n++;
	    XtSetArg( args[n], XmwNspotLocationY, prop[15] );	n++;
	}
	if( prop[0] & (AllInformation | FrameInformation) ) {
	    XtSetArg( args[n], XmwNlineSpacing, prop[16] );	n++;
	}

	if( p->buffer->preedit_widget == NULL ) {
	    char	ss[20];

	    XGetWindowAttributes( display, prop[1], &attr );

	    XtSetArg( args[n], XmwNfocusWindow, p->info->in_win );	n++;
	    XtSetArg( args[n], XmwNblinkRate, 0 );			n++;
	    XtSetArg( args[n], XmwNfocus, True );			n++;
	    XtSetArg( args[n], XtNdepth, attr.depth );			n++;
	    XtSetArg( args[n], XtNscreen, attr.screen );		n++;
	    XtSetArg( args[n], XtNcolormap, attr.colormap );		n++;
	    XtSetArg( args[n], XtNaccelerators, resources.base_accelerators );
	    n++;
	    sprintf( ss, "xlc_pre%08x", id++ );
	    p->buffer->preedit_widget = XmwCreatePreedit( TopLevel, ss, args,
							  n );
	    XtInstallAccelerators( p->buffer->preedit_widget,
				   p->buffer->preedit_widget );
	    XmwPreeditMapWidget( p->buffer->preedit_widget );
	    XMapRaised( display, p->input_window );
	    XSelectInput( display, p->info->in_win,
			  ExposureMask | StructureNotifyMask );
	    SendConversionNotify( p );
	}
	else
	    XtSetValues( p->buffer->preedit_widget, args, n );

	XFree( prop );
    }
}


static void
#if NeedFunctionPrototypes
procPropertyChangeMask( Widget w, XtPointer client_data, XEvent *event,
			Boolean *continue_to_dispatch )
#else
procPropertyChangeMask( w, client_data, event, continue_to_dispatch )
    Widget	 w;
    XtPointer	 client_data;
    XEvent	*event;
    Boolean	*continue_to_dispatch;
#endif
{
    static Boolean	 init = False;
    XPropertyEvent	*ev = (XPropertyEvent *)event;

    if( resources.xlc_protocol ) {
	if( !init ) {
	    set_xlc_selection_owner( XtDisplay(w), XtWindow(w), ev->time );
	    init = True;
	}
	else if( ev->state == PropertyNewValue )
	    XlcpPropertyChange( ev );
    }
}


void	xlc_protocol_initialize( display )
    Display	*display;
{
    unsigned long	data[10];

    if( !resources.xlc_protocol )
	return;

    XtAddEventHandler( TopLevel, NoEventMask, True, procNoEventMask, NULL );
    XtAddEventHandler( TopLevel, PropertyChangeMask, False,
		       procPropertyChangeMask, NULL );

    /* setup properties */
    conversion_request = XInternAtom( display, CONVERSION_REQUEST, False );
    conversion_notify = XInternAtom( display, CONVERSION_NOTIFY, False );
    conversion_end_request = XInternAtom( display, CONVERSION_END_REQUEST,
					  False );
    conversion_end = XInternAtom( display, CONVERSION_END, False );
    conversion_close = XInternAtom( display, CONVERSION_CLOSE, False );
    conversion_property = XInternAtom( display, CONVERSION_PROPERTY, False );
    conversion_attribute_notify = XInternAtom( display,
					       CONVERSION_ATTRIBUTE_NOTIFY,
					       False );
    conversion_inplace = XInternAtom( display, CONVERSION_INPLACE, False );
    compound_text = XInternAtom( display, COMPOUND_TEXT, False );

    conversion_profile = XInternAtom( display, CONVERSION_PROFILE, False );
    conversion_attribute_type = XInternAtom( display, CONVERSION_ATTRIBUTE_TYPE,
					     False );

    data[0] = (PROTOCOL_VERSION_MASK << 16) | 1;
    data[1] = XInternAtom( display, PROTOCOL_VERSION, False );
    data[2] = (SUPPORTED_STYLES_MASK << 16) | 1;
    data[3] = ROOT_WINDOW_STYLE | OFF_THE_SPOT_STYLE | OVER_THE_SPOT_STYLE;
    XChangeProperty( display, XtWindow(TopLevel), conversion_profile,
		     conversion_attribute_type, 32, PropModeReplace,
		     (unsigned char *)data, 4 );
}


static void
#if NeedFunctionPrototypes
delete_property_queue( PropertyQueue *p )
#else
delete_property_queue( p )
    PropertyQueue	*p;
#endif
{
    if( p->previous )
	p->previous->next = p->next;
    else
	property_queue = p->next;
    if( p->next )
	p->next->previous = p->previous;

    if( p->connect_flag ) {
	if( p->buffer->error_shell )
	    error_cancel( (Widget)NULL, (caddr_t)p->buffer, (caddr_t)NULL );
	if( p->buffer->state & DELETE )
	    sakujo_cancel( (Widget)NULL, (caddr_t)p->buffer, (caddr_t)NULL );
	if( p->buffer->state & CODE )
	    code_cancel( (Widget)NULL, (caddr_t)p->buffer, (caddr_t)NULL );
	if( p->buffer->state & ADD )
	    touroku_cancel( (Widget)NULL, (caddr_t)p->buffer, (caddr_t)NULL );
	if( p->buffer->state & SERVER )
	    reconnect_cancel( (Widget)NULL, (caddr_t)p->buffer, (caddr_t)NULL );
	if( p->buffer->state & SELECT ) {
	    if( p->buffer->conversion_style ==
		(XIMPreeditNothing | XIMStatusNothing) )
		XtUnmapWidget( RootTextField );
	    else if( p->buffer->conversion_style & XIMPreeditPosition )
		select_dialog_cancel( (Widget)NULL, (caddr_t)p->buffer,
				      (caddr_t)NULL );
	}
	if( p->buffer->state & EDIT )
	    edit_cancel( p->buffer );
	if( p->buffer->state & (WRAP | CONVERSION) )
	    henkan_cancel( p->buffer );
    }
    if( p->info ) {
	if( buffer == p->buffer )
	    sort_buffer( &root_window );
	free( (char *)p->info );
	buffer_free( p->buffer );
    }
    else
	p->buffer->connect--;
    free( (char *)p );
}


Boolean	XlcpSendCompoundText( display, w, string )
    Display	*display;
    Window	 w;
    wchar_t	*string;
{
    register PropertyQueue	*p;
    XTextProperty		 text;
    wchar_t			*list[1];

    if( (p = search_client_window( w )) == NULL )
	return( False );
    list[0] = string;
    XwcTextListToTextProperty( display, list, 1, XCompoundTextStyle, &text );
    XChangeProperty( display, p->client_window, p->client_property,
		     p->client_text, 8, PropModeAppend,
		     text.value, text.nitems );
    XFree( text.value );

    if( p->buffer->conversion_style & XIMPreeditNothing )
	XmwTextOutSetString( RootText, NULL, XmwHIGHLIGHT_NORMAL );
    else {
	if( (p->info  &&  p->info->in_flag & 1)  ||
	    (p->kinput2  &&  resources.auto_replace) )
	    XmwPreeditAutoReplace( p->buffer->preedit_widget );
	else
	    XmwPreeditSetString( p->buffer->preedit_widget, NULL,
				 XmwHIGHLIGHT_SECONDARY_SELECTED );
    }

    return( True );
}


Boolean	XlcpSendKeyEvent( w, event )
    Window	 w;
    XKeyEvent	*event;
{
    register PropertyQueue	*p;
    int				 n;
    char			*list[1], string[256];
    KeySym			 keysym;
    XTextProperty		 text;

    p = search_client_window( w );
    if( p != NULL ) {
	if( ISXlcp(p) ) {
	    event->window = p->client_window;
	    XSendEvent( event->display, p->client_window, False, NULL,
			(XEvent *)event );
	}
	else {
	    if( (n = XLookupString( event, string, 256, &keysym,
				    NULL )) != 0 ) {
		switch( keysym ) {
		  case XK_Tab:
		  case XK_Escape:
		    string[0] = keysym & 0x00ff;
		    n = 1;
		    break;

		  case XK_Return:
		    string[0] = 0x0a;
		    n = 1;
		    break;

		  default:
		    event->window = p->client_window;
		    XSendEvent( event->display, p->client_window, False, NULL,
				(XEvent *)event );
		    return( True );
		}
		string[n] = '\0';
		XChangeProperty( event->display, p->client_window,
				 p->client_property, p->client_text, 8,
				 PropModeAppend, (unsigned char *)string, n );
	    }
	}
	return( True );
    }
    return( False );
}


void	XlcpSetBCKey( widget )
    Widget	widget;
{
    Display		*display = XtDisplay(widget);
    Window		 window = XtWindow(widget);
    Atom		 kprop, mprop;
    unsigned int	 keycode, modifier;

    if( !resources.xlc_protocol )
	return;
    XlcpConversion( OFF );
    if( resources.process_start_keys[0].keysym == XK_VoidSymbol )
	return;

    kprop = XInternAtom( display, "_XLC_BC_KEYCODE", False );
    mprop = XInternAtom( display, "_XLC_BC_MODIFIER", False );

    keycode = XKeysymToKeycode( display,
				resources.process_start_keys[0].keysym );
    modifier = resources.process_start_keys[0].modifier;

    XChangeProperty( display, window, kprop, XA_INTEGER, 32,
		     PropModeReplace, (unsigned char *)&keycode, 1 );
    XChangeProperty( display, window, mprop, XA_INTEGER, 32,
		     PropModeReplace, (unsigned char *)&modifier, 1 );
}


Boolean
#if NeedFunctionPrototypes
XlcpCheckState( State state )
#else /* NeedFunctionPrototypes */
XlcpCheckState( state )
    State	state;
#endif /* NeedFunctionPrototypes */
{
    PropertyQueue	*q;

    for( q = property_queue; q != NULL; q = q->next )
	if( q->buffer->state & state )
	    return( True );
    return( False );
}


Boolean
#if NeedFunctionPrototypes
XlcpDestroyNotify( XEvent *event )
#else /* NeedFunctionPrototypes */
XlcpDestroyNotify( event )
    XEvent	*event;
#endif /* NeedFunctionPrototypes */
{
    register PropertyQueue	*p;

    if( (p = search_client_window(event->xdestroywindow.window)) != NULL ) {
	if( p->connect_flag  ||  p->conversion_close_flag ) {
	    RootWindowUnmap( p->buffer->conversion_style );
	    xlc_count--;
	    if( xlc_count == 0 )
		XlcpConversion( OFF );
	}
	delete_property_queue( p );
	return( True );
    }
    else
	return( False );
}


Boolean
#if NeedFunctionPrototypes
XlcpChangeExpose( XEvent *event )
#else /* NeedFunctionPrototypes */
XlcpChangeExpose( event )
    XEvent	*event;
#endif /* NeedFunctionPrototypes */
{
    PropertyQueue	*p;

    for( p = property_queue; p != NULL; p = p->next ) {
	if( p->info  &&  p->info->in_win == event->xexpose.window ) {
	    event->xexpose.window = XtWindow( p->buffer->preedit_widget );
	    return( True );
	}
    }
    return( False );
}


Boolean
#if NeedFunctionPrototypes
XlcpPreeditChangeKeyDirection( XEvent *event )
#else /* NeedFunctionPrototypes */
XlcpPreeditChangeKeyDirection( event )
    XEvent	*event;
#endif /* NeedFunctionPrototypes */
{
    PropertyQueue	*q;

    if( (q = search_client_window( event->xkey.window )) == NULL )
	return( False );

    event->xkey.window = XtWindow( q->buffer->preedit_widget );
    XtSetKeyboardFocus( TopLevel, q->buffer->preedit_widget );
    return( True );
}


Boolean
#if NeedFunctionPrototypes
XlcpIsRegisteredWindow( Window c, Window f )
#else /* NeedFunctionPrototypes */
XlcpIsRegisteredWindow( c, f )
    Window	c, f;
#endif /* NeedFunctionPrototypes */
{
    PropertyQueue	*q;

    for( q = property_queue; q != NULL; q = q->next )
	if( q->client_window == c  ||  q->client_window == f )
	    return( True );
    return( False );
}
#endif
