/* $SonyId: XlcpP.h,v 1.3 1995/06/19 10:37:08 makoto Exp $ */
/******************************************************************

Copyright (c) 1992, 1993, 1994  Sony Corporation

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL SONY CORPORATION BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of Sony Corporation shall
not be used in advertising or otherwise to promote the sale, use or ot
her dealings in this Software without prior written authorization from
Sony Corporation.

******************************************************************/
#ifndef _XlcpP_H
#define _XlcpP_H
#include	"Xlcp.h"

#define XLC_PROTOCOL			0
#define KINPUT2_PROTOCOL		1

#define JAPANESE_CONVERSION		"JAPANESE_CONVERSION"
#define _JAPANESE_CONVERSION		"_JAPANESE_CONVERSION"

#define _CONVERSION_PROFILE		"_CONVERSION_PROFILE"
#define _CONVERSION_ATTRIBUTE_TYPE	"_CONVERSION_ATTRIBUTE_TYPE"

#define PROTOCOL_VERSION		"PROTOCOL-2.0"

#define PROTOCOL_VERSION_MASK		1
#define SUPPORTED_STYLES_MASK		2
#define SUPPORTED_EXTENSIONS_MASK	3

#define	CONVERSION_REQUEST		"CONVERSION_REQUEST"
#define	CONVERSION_NOTIFY		"CONVERSION_NOTIFY"
#define	CONVERSION_END			"CONVERSION_END"
#define	CONVERSION_END_REQUEST		"CONVERSION_END_REQUEST"
#define CONVERSION_CLOSE		"CONVERSION_CLOSE"
#define CONVERSION_PROPERTY		"CONVERSION_PROPERTY"
#define CONVERSION_ATTRIBUTE_NOTIFY	"CONVERSION_ATTRIBUTE_NOTIFY"

#define CONVERSION_PROFILE		"_CONVERSION_PROFILE"
#define CONVERSION_ATTRIBUTE_TYPE	"_CONVERSION_ATTRIBUTE_TYPE"

#define COMPOUND_TEXT			"COMPOUND_TEXT"

#define CONVERSION_INPLACE		"_XLC_ON_THE_SPOT"
#define CONVERSION_STATUS		"_XLC_STATUS"

#define NO_OPERATION_MASK		0
#define INDIRECT_ATTRIBUTE_MAKS		1
#define FOCUS_WINDOW_MASK		2
#define SPOT_LOCATION_MASK		3
#define CLIENT_AREA_MASK		4
#define STATUS_AREA_MASK		5
#define COLORMAP_MASK			6
#define COLOR_MASK			7
#define BG_PIXMAP_MASK			8
#define LINE_SPACING_MASK		9
#define FONT_ATOM_MASK			10
#define CURSOR_MASK			11

#define INPUT_STYLE_MASK		128
#define EVENT_CAPTURE_METHOD_MASK	129
#define USE_EXTENSION_MASK		130

#define ROOT_WINDOW_STYLE		1
#define OFF_THE_SPOT_STYLE		2
#define OVER_THE_SPOT_STYLE		4

#define SEND_EVENT			0
#define INPUT_ONLY_WINDOW_EVENT		1
#define SELECT_INPUT_EVENT		2

#define ISXlcp(q)	((q)->protocol == XLC_PROTOCOL)
#define ISKinput2(q)	((q)->protocol == KINPUT2_PROTOCOL)

typedef struct _InplaceWindowAttributes {
    unsigned long		back;
    unsigned long		border;
    unsigned int		bwidth;
} InplaceWindowAttributes;

typedef struct _InplaceDrawingSet {
    unsigned long		fore;
    unsigned long		back;
    Font			font8;
    Font			font16;
    Font			efont16;
} InplaceDrawingSet;

typedef struct _InplaceFrame {
    unsigned int		x;
    unsigned int		y;
    unsigned int		width;
    unsigned int		height;
    unsigned int		x_off;
    unsigned int		y_off;
    unsigned int		line_height;
} InplaceFrame;

typedef struct _InplaceInfo {
    unsigned int		in_flag;
    Window			in_win;
    InplaceWindowAttributes	in_attr;
    InplaceDrawingSet		in_draw;
    InplaceFrame		in_frame;
} InplaceInfo;

typedef struct _Kinput2Info {
    unsigned long		mask;
    unsigned long		event_capture_method;
    Window			focus_window;
    Colormap			colormap;
    unsigned long		foreground;
    unsigned long		background;
    Pixmap			pixmap;
    XFontSet			font_set;
    int				ascent;
} Kinput2Info;


#define AutoReplace		1
#define AllInformation		2
#define FrameInformation	4
#define OffsetInformation	8

typedef struct _PropertyQueue {
    struct _PropertyQueue	*next;
    struct _PropertyQueue	*previous;
    unsigned long		 protocol;
    Window			 input_window;
    Window			 client_window;
    Atom			 client_text;
    Atom			 client_property;
    Atom			 client_inplace;
    Atom			 selection;
    InplaceInfo			*info;
    Kinput2Info			*kinput2;
    Boolean			 connect_flag;
    Boolean			 conversion_close_flag;
    Buffer			*buffer;
} PropertyQueue;

#endif /* _XlcpP_H */
